# -*- coding: utf-8 -*-
import logging
from logging.handlers import RotatingFileHandler
from config.settings import Settings
import os

class LogManager:
    _instance = None
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._init_logger()
        return cls._instance
    
    def _init_logger(self):
        log_file = Settings.LOGS_DIR / "system.log"
        self.logger = logging.getLogger("ArchiveSystem")
        self.logger.setLevel(logging.INFO)
        handler = RotatingFileHandler(str(log_file), maxBytes=5*1024*1024, backupCount=5, encoding='utf-8')
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)
    
    def info(self, msg):
        self.logger.info(msg)
    
    def error(self, msg):
        self.logger.error(msg)
    
    def warning(self, msg):
        self.logger.warning(msg)