# -*- coding: utf-8 -*-
from services.report_service import ReportService

class DashboardController:
    def __init__(self, db_manager):
        self.report_service = ReportService(db_manager)
    
    def get_stats(self):
        return self.report_service.generate_statistics()