# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import QMessageBox
from ui.login_window import LoginWindow
from ui.main_window import MainWindow
from services.auth_service import AuthService
from database.db_manager import DatabaseManager
from logs.log_manager import LogManager

class AuthController:
    def __init__(self, db_manager: DatabaseManager, log_manager: LogManager):
        self.db_manager = db_manager
        self.log_manager = log_manager
        self.auth_service = AuthService(db_manager)
        self.login_window = None
        self.main_window = None
    
    def show_login(self):
        self.login_window = LoginWindow(self)
        self.login_window.show()
    
    def login(self, username: str, password: str):
        user = self.auth_service.authenticate(username, password)
        if user:
            self.login_window.close()
            self.main_window = MainWindow(self.db_manager, self.log_manager, user)
            self.main_window.show()
        else:
            QMessageBox.warning(self.login_window, "خطأ", "اسم المستخدم أو كلمة المرور غير صحيحة")
    
    def logout(self):
        if self.main_window:
            self.main_window.close()
        self.show_login()