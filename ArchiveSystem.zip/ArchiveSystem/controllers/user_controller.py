# -*- coding: utf-8 -*-
from services.user_service import UserService

class UserController:
    def __init__(self, db_manager):
        self.user_service = UserService(db_manager)
    
    def get_all_users(self):
        return self.user_service.get_all_users()
    
    def add_user(self, username, password, full_name, email, role):
        return self.user_service.add_user(username, password, full_name, email, role)
    
    def update_user(self, user_id, full_name, email, role, is_active):
        return self.user_service.update_user(user_id, full_name, email, role, is_active)
    
    def delete_user(self, user_id):
        return self.user_service.delete_user(user_id)