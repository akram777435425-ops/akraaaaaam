# -*- coding: utf-8 -*-
from services.document_service import DocumentService
from services.tag_service import TagService
from services.classification_service import ClassificationService

class DocumentController:
    def __init__(self, db_manager):
        self.doc_service = DocumentService(db_manager)
        self.tag_service = TagService(db_manager)
        self.class_service = ClassificationService(db_manager)
    
    def add_document(self, data, attachments_paths=None):
        """إضافة وثيقة جديدة مع المرفقات (اختياري)"""
        return self.doc_service.add_document(data, attachments_paths)
    
    def update_document(self, doc_id, data, attachments_paths=None):
        """تحديث وثيقة موجودة مع إضافة مرفقات جديدة (اختياري)"""
        return self.doc_service.update_document(doc_id, data, attachments_paths)
    
    def delete_document(self, doc_id, hard=False):
        return self.doc_service.delete_document(doc_id, hard)
    
    def restore_document(self, doc_id):
        return self.doc_service.restore_document(doc_id)
    
    def get_all_documents(self, archived=False):
        return self.doc_service.get_all_documents(archived)
    
    def add_attachment(self, doc_id, file_path, user_id):
        return self.doc_service.add_attachment(doc_id, file_path, user_id)
    
    def get_attachments(self, doc_id):
        return self.doc_service.get_attachments(doc_id)
    
    def delete_attachment(self, attachment_id):
        return self.doc_service.delete_attachment(attachment_id)