# -*- coding: utf-8 -*-
import pytest
import os
import tempfile
from database.db_manager import DatabaseManager
from services.user_service import UserService
from config.settings import Settings

@pytest.fixture
def temp_db():
    """إنشاء قاعدة بيانات مؤقتة للاختبار"""
    original_db_path = Settings.DB_PATH
    temp_db = tempfile.NamedTemporaryFile(suffix='.db', delete=False)
    Settings.DB_PATH = temp_db.name
    db_manager = DatabaseManager()
    db_manager.initialize_database()
    yield db_manager
    Settings.DB_PATH = original_db_path
    os.unlink(temp_db.name)

def test_add_user(temp_db):
    user_service = UserService(temp_db)
    result = user_service.add_user("testuser", "Test@123", "Test User", "test@example.com", "user")
    assert result == True
    user = user_service.get_user_by_username("testuser")
    assert user is not None
    assert user['username'] == "testuser"

def test_add_duplicate_user(temp_db):
    user_service = UserService(temp_db)
    user_service.add_user("duplicate", "Test@123", "Duplicate", "dup@example.com", "user")
    result = user_service.add_user("duplicate", "Test@123", "Duplicate2", "dup2@example.com", "user")
    assert result == False

def test_change_password(temp_db):
    user_service = UserService(temp_db)
    user_service.add_user("passuser", "Old@123", "Pass User", "pass@example.com", "user")
    user = user_service.get_user_by_username("passuser")
    assert user is not None
    result = user_service.change_password(user['id'], "New@456")
    assert result == True

def test_delete_user(temp_db):
    user_service = UserService(temp_db)
    user_service.add_user("deleteuser", "Test@123", "Delete User", "del@example.com", "user")
    user = user_service.get_user_by_username("deleteuser")
    assert user is not None
    result = user_service.delete_user(user['id'])
    assert result == True
    assert user_service.get_user_by_username("deleteuser") is None

def test_cannot_delete_admin(temp_db):
    user_service = UserService(temp_db)
    # المستخدم admin موجود مسبقاً
    admin = user_service.get_user_by_username("admin")
    assert admin is not None
    result = user_service.delete_user(admin['id'])
    assert result == False