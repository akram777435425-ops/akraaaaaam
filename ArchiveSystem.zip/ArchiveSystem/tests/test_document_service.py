# -*- coding: utf-8 -*-
import pytest
import os
import tempfile
from database.db_manager import DatabaseManager
from services.document_service import DocumentService
from config.settings import Settings

@pytest.fixture
def temp_db():
    original_db_path = Settings.DB_PATH
    temp_db = tempfile.NamedTemporaryFile(suffix='.db', delete=False)
    Settings.DB_PATH = temp_db.name
    db_manager = DatabaseManager()
    db_manager.initialize_database()
    yield db_manager
    Settings.DB_PATH = original_db_path
    os.unlink(temp_db.name)

def test_generate_doc_number(temp_db):
    doc_service = DocumentService(temp_db)
    doc_number = doc_service.generate_doc_number()
    assert doc_number.startswith("DOC-")
    assert len(doc_number) >= 10

def test_sanitize_folder_name(temp_db):
    doc_service = DocumentService(temp_db)
    dirty_name = "وزارة/المالية<>?*"
    clean_name = doc_service.sanitize_folder_name(dirty_name)
    assert "وزارةالمالية" in clean_name
    assert "/" not in clean_name
    assert "<" not in clean_name