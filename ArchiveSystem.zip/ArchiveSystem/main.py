# -*- coding: utf-8 -*-
"""
ArchiveSystem - نظام أرشيف إلكتروني احترافي
تصميم: ن/أكرم ياسين 777425435
"""
import sys
import os
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from database.db_manager import DatabaseManager
from logs.log_manager import LogManager
from controllers.auth_controller import AuthController

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("ArchiveSystem")
    
    # تعيين الخط الافتراضي لدعم العربية
    font = QFont("Segoe UI", 10)
    app.setFont(font)
    
    # تهيئة المديرين
    db_manager = DatabaseManager()
    log_manager = LogManager()
    
    # التحقق من وجود قاعدة البيانات وإنشاء الجداول
    db_manager.initialize_database()
    
    # تشغيل شاشة تسجيل الدخول
    auth_controller = AuthController(db_manager, log_manager)
    auth_controller.show_login()
    
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()