# -*- coding: utf-8 -*-
import hashlib
import os
import re

def hash_password(password: str) -> str:
    """تشفير كلمة المرور باستخدام SHA256 (للتطابق مع النظام الحالي)"""
    return hashlib.sha256(password.encode('utf-8')).hexdigest()

def is_strong_password(password: str) -> bool:
    """
    التحقق من قوة كلمة المرور:
    - 8 أحرف على الأقل
    - حرف كبير واحد على الأقل
    - رقم واحد على الأقل
    - رمز خاص واحد على الأقل
    """
    if len(password) < 8:
        return False
    if not re.search(r'[A-Z]', password):
        return False
    if not re.search(r'[0-9]', password):
        return False
    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        return False
    return True

def sanitize_path(path: str) -> str:
    """تنظيف المسار من الأحرف غير المسموح بها لأنظمة الملفات"""
    invalid_chars = r'<>:"/\|?*'
    for ch in invalid_chars:
        path = path.replace(ch, '')
    return path.strip()

def validate_transaction_number(number: str, year: int, transaction_type: str) -> bool:
    """التحقق من صحة رقم المعاملة (مثال: 2025-001)"""
    pattern = r'^\d{4}-\d{3,6}$'
    if not re.match(pattern, number):
        return False
    # التحقق من السنة
    if int(number[:4]) != year:
        return False
    return True