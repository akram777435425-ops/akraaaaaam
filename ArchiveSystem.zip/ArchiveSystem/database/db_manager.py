# -*- coding: utf-8 -*-
import sqlite3
import hashlib
import os
from contextlib import contextmanager
from config.settings import Settings
from logs.log_manager import LogManager

class DatabaseManager:
    def __init__(self):
        self.db_path = Settings.DB_PATH
        self.logger = LogManager()

    def initialize_database(self):
        self.create_tables()
        if self.get_user_count() == 0:
            self.create_default_admin()
        if self.get_contacts_count() == 0:
            self.create_default_contacts()

    def get_user_count(self) -> int:
        with self.get_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) as cnt FROM users")
            return cur.fetchone()['cnt'] or 0

    def get_contacts_count(self) -> int:
        with self.get_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) as cnt FROM contacts")
            return cur.fetchone()['cnt'] or 0

    @contextmanager
    def get_connection(self):
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            self.logger.error(f"Database error: {e}")
            raise
        finally:
            conn.close()

    def create_tables(self):
        with self.get_connection() as conn:
            cursor = conn.cursor()
            # جدول المستخدمين (بدون salt للحفاظ على البساطة)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    password TEXT NOT NULL,
                    full_name TEXT,
                    email TEXT,
                    role TEXT DEFAULT 'user',
                    is_active INTEGER DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_login TIMESTAMP
                )
            ''')
            # جدول سجل النشاط
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS activity_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    action TEXT,
                    details TEXT,
                    ip_address TEXT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(user_id) REFERENCES users(id)
                )
            ''')
            # جدول الصلاحيات التفصيلية
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS user_permissions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    permission_key TEXT,
                    granted INTEGER DEFAULT 1,
                    FOREIGN KEY(user_id) REFERENCES users(id),
                    UNIQUE(user_id, permission_key)
                )
            ''')
            # جدول جهات الاتصال (المرسلين والمستلمين)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS contacts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    contact_type TEXT NOT NULL,
                    code TEXT,
                    phone TEXT,
                    email TEXT,
                    address TEXT,
                    notes TEXT,
                    is_active INTEGER DEFAULT 1
                )
            ''')
            # جدول التصنيفات
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS categories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    parent_id INTEGER,
                    code TEXT,
                    description TEXT,
                    FOREIGN KEY(parent_id) REFERENCES categories(id)
                )
            ''')
            # جدول الجهات الخارجية
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS correspondents (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    code TEXT UNIQUE,
                    name TEXT NOT NULL,
                    type TEXT,
                    contact_person TEXT,
                    phone TEXT,
                    email TEXT,
                    address TEXT,
                    notes TEXT
                )
            ''')
            # جدول الوثائق (مع حقل مؤشرات إضافية)
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS documents (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    doc_number TEXT UNIQUE NOT NULL,
                    transaction_number TEXT NOT NULL,
                    title TEXT NOT NULL,
                    description TEXT,
                    doc_type TEXT,
                    doc_status TEXT,
                    category_id INTEGER,
                    correspondent_id INTEGER,
                    doc_date DATE,
                    incoming_outgoing TEXT,
                    priority TEXT,
                    tags TEXT,
                    storage_location TEXT,
                    preservation_year INTEGER,
                    destruction_period INTEGER,
                    added_by INTEGER,
                    added_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    modified_by INTEGER,
                    modified_date TIMESTAMP,
                    is_archived INTEGER DEFAULT 0,
                    archive_date TIMESTAMP,
                    restored_date TIMESTAMP,
                    sender_id INTEGER,
                    recipient_id INTEGER,
                    confidentiality TEXT DEFAULT 'normal',
                    review_date DATE,
                    location_code TEXT,
                    archive_path TEXT,
                    year INTEGER,
                    FOREIGN KEY(category_id) REFERENCES categories(id),
                    FOREIGN KEY(correspondent_id) REFERENCES correspondents(id),
                    FOREIGN KEY(sender_id) REFERENCES contacts(id),
                    FOREIGN KEY(recipient_id) REFERENCES contacts(id),
                    FOREIGN KEY(added_by) REFERENCES users(id),
                    UNIQUE(transaction_number, year, incoming_outgoing)
                )
            ''')
            # جدول المرفقات
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS attachments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    document_id INTEGER,
                    filename TEXT,
                    filepath TEXT,
                    filetype TEXT,
                    filesize INTEGER,
                    uploaded_by INTEGER,
                    upload_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(document_id) REFERENCES documents(id)
                )
            ''')
            # جدول المراسلات
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS correspondences (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    doc_id INTEGER,
                    from_entity TEXT,
                    to_entity TEXT,
                    subject TEXT,
                    content TEXT,
                    sent_date DATE,
                    received_date DATE,
                    status TEXT,
                    tracking_number TEXT,
                    FOREIGN KEY(doc_id) REFERENCES documents(id)
                )
            ''')
            # جدول المهام
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    document_id INTEGER,
                    assigned_to INTEGER,
                    title TEXT,
                    description TEXT,
                    due_date DATE,
                    status TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(document_id) REFERENCES documents(id),
                    FOREIGN KEY(assigned_to) REFERENCES users(id)
                )
            ''')
            # جدول الملاحظات
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS notes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    document_id INTEGER,
                    user_id INTEGER,
                    note TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(document_id) REFERENCES documents(id),
                    FOREIGN KEY(user_id) REFERENCES users(id)
                )
            ''')
            # جدول الكلمات المفتاحية
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS tags (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT UNIQUE,
                    usage_count INTEGER DEFAULT 0
                )
            ''')
            # جدول ربط الوثائق بالكلمات المفتاحية
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS document_tags (
                    document_id INTEGER,
                    tag_id INTEGER,
                    PRIMARY KEY(document_id, tag_id),
                    FOREIGN KEY(document_id) REFERENCES documents(id),
                    FOREIGN KEY(tag_id) REFERENCES tags(id)
                )
            ''')
            # جدول إعدادات النظام
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS system_settings (
                    key TEXT PRIMARY KEY,
                    value TEXT
                )
            ''')
            # الفهارس المحسّنة
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_doc_date ON documents(doc_date)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_added_date ON documents(added_date)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_incoming_outgoing ON documents(incoming_outgoing)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_doc_status ON documents(doc_status)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_correspondent ON documents(correspondent_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_sender ON documents(sender_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_recipient ON documents(recipient_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_transaction_number ON documents(transaction_number)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_year ON documents(year)")
            # فهارس إضافية للبحث السريع
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_title ON documents(title)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_tags ON documents(tags)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_username ON users(username)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_contact_type ON contacts(contact_type)")
            # إدراج الصلاحيات الافتراضية
            cursor.execute("INSERT OR IGNORE INTO roles_permissions VALUES ('admin', 'all')")
            cursor.execute("INSERT OR IGNORE INTO roles_permissions VALUES ('user', 'view,search')")

    def create_default_admin(self):
        with self.get_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT id FROM users WHERE username='admin'")
            if not cur.fetchone():
                hashed = hashlib.sha256("admin123".encode()).hexdigest()
                cur.execute("INSERT INTO users (username, password, full_name, role, is_active) VALUES (?,?,?,?,?)",
                            ("admin", hashed, "مدير النظام", "admin", 1))

    def create_default_contacts(self):
        with self.get_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM contacts")
            if cur.fetchone()[0] == 0:
                default_contacts = [
                    ("إدارة الموارد البشرية", "sender", "HR", "", "", "", ""),
                    ("إدارة المالية", "sender", "FIN", "", "", "", ""),
                    ("قسم المشتريات", "recipient", "PUR", "", "", "", ""),
                    ("قسم التدقيق", "recipient", "AUD", "", "", "", ""),
                    ("مدير عام", "both", "GM", "", "", "", ""),
                    ("مسؤول الأرشيف", "both", "ARC", "", "", "", ""),
                ]
                for name, ctype, code, phone, email, address, notes in default_contacts:
                    cur.execute("""
                        INSERT INTO contacts (name, contact_type, code, phone, email, address, notes, is_active)
                        VALUES (?, ?, ?, ?, ?, ?, ?, 1)
                    """, (name, ctype, code, phone, email, address, notes))