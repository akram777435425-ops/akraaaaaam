# -*- coding: utf-8 -*-
from dataclasses import dataclass
from datetime import date, datetime
from typing import Optional, List

@dataclass
class User:
    id: Optional[int]
    username: str
    password: str
    full_name: str
    email: str
    role: str
    is_active: bool
    created_at: datetime
    last_login: Optional[datetime]

@dataclass
class Document:
    id: Optional[int]
    doc_number: str
    transaction_number: str   # حقل جديد
    title: str
    description: Optional[str]
    doc_type: Optional[str]
    doc_status: Optional[str]
    category_id: Optional[int]
    correspondent_id: Optional[int]
    doc_date: Optional[date]
    incoming_outgoing: Optional[str]
    priority: Optional[str]
    tags: Optional[str]
    storage_location: Optional[str]
    preservation_year: Optional[int]
    destruction_period: Optional[int]
    added_by: int
    added_date: datetime
    modified_by: Optional[int]
    modified_date: Optional[datetime]
    is_archived: bool
    archive_date: Optional[datetime]
    restored_date: Optional[datetime]
    sender: Optional[str]
    recipient: Optional[str]
    confidentiality: str
    review_date: Optional[date]
    location_code: Optional[str]
    archive_path: Optional[str]
    year: int

@dataclass
class Category:
    id: Optional[int]
    name: str
    parent_id: Optional[int]
    code: Optional[str]
    description: Optional[str]

@dataclass
class Correspondent:
    id: Optional[int]
    code: str
    name: str
    type: Optional[str]
    contact_person: Optional[str]
    phone: Optional[str]
    email: Optional[str]
    address: Optional[str]
    notes: Optional[str]