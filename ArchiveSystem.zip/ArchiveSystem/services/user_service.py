# -*- coding: utf-8 -*-
import hashlib
import datetime
from database.db_manager import DatabaseManager
from logs.log_manager import LogManager

class UserService:
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
        self.logger = LogManager()

    @staticmethod
    def _hash_password(password: str) -> str:
        return hashlib.sha256(password.encode('utf-8')).hexdigest()

    def get_all_users(self):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, username, full_name, email, role, is_active, created_at, last_login FROM users ORDER BY id")
            return [dict(row) for row in cursor.fetchall()]

    def get_user_by_username(self, username: str):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, username, full_name, email, role, is_active FROM users WHERE username=?", (username,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def add_user(self, username: str, password: str, full_name: str, email: str, role: str) -> bool:
        try:
            if self.get_user_by_username(username):
                return False
            hashed = self._hash_password(password.strip())
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO users (username, password, full_name, email, role, is_active, created_at)
                    VALUES (?, ?, ?, ?, ?, 1, ?)
                """, (username.strip(), hashed, full_name.strip(), email.strip(), role, datetime.datetime.now()))
                self.logger.info(f"User {username} added")
                return True
        except Exception as e:
            self.logger.error(f"Add user error: {e}")
            return False

    def update_user(self, user_id: int, full_name: str, email: str, role: str, is_active: int) -> bool:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE users SET full_name=?, email=?, role=?, is_active=? WHERE id=?", (full_name, email, role, is_active, user_id))
            return cursor.rowcount > 0

    def delete_user(self, user_id: int) -> bool:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT role FROM users WHERE id=?", (user_id,))
            row = cursor.fetchone()
            if row and row['role'] == 'admin':
                return False
            cursor.execute("DELETE FROM users WHERE id=?", (user_id,))
            return cursor.rowcount > 0

    def change_password(self, user_id: int, new_password: str) -> bool:
        hashed = self._hash_password(new_password.strip())
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE users SET password=? WHERE id=?", (hashed, user_id))
            return cursor.rowcount > 0