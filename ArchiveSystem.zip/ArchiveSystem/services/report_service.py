# -*- coding: utf-8 -*-
import csv
import datetime
from pathlib import Path
from database.db_manager import DatabaseManager
from logs.log_manager import LogManager
from config.settings import Settings
from services.setting_service import SettingService

class ReportService:
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
        self.logger = LogManager()
        self.setting_service = SettingService(db_manager)

    def _get_archive_root(self):
        """إرجاع مسار الأرشيف الفعلي (قد يكون معدلاً من الإعدادات)"""
        return self.setting_service.get_archive_path()

    def generate_statistics(self) -> dict:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) as total FROM documents")
            total_docs = cursor.fetchone()['total']
            cursor.execute("SELECT COUNT(*) as archived FROM documents WHERE is_archived=1")
            archived_docs = cursor.fetchone()['archived']
            cursor.execute("SELECT COUNT(*) as incoming FROM documents WHERE incoming_outgoing='وارد'")
            incoming = cursor.fetchone()['incoming']
            cursor.execute("SELECT COUNT(*) as outgoing FROM documents WHERE incoming_outgoing='صادر'")
            outgoing = cursor.fetchone()['outgoing']

            archive_root = self._get_archive_root()
            total_size = 0
            if archive_root.exists():
                for f in archive_root.rglob("*"):
                    if f.is_file():
                        total_size += f.stat().st_size
            return {
                'total_documents': total_docs,
                'archived_documents': archived_docs,
                'incoming_count': incoming,
                'outgoing_count': outgoing,
                'storage_used_mb': round(total_size / (1024*1024), 2)
            }

    def export_to_excel(self, data: list, filepath: str) -> bool:
        try:
            from openpyxl import Workbook
            wb = Workbook()
            ws = wb.active
            ws.title = "التقرير"
            if data:
                headers = list(data[0].keys())
                ws.append(headers)
                for row in data:
                    ws.append([row.get(h, '') for h in headers])
            wb.save(filepath)
            self.logger.info(f"Excel report saved to {filepath}")
            return True
        except ImportError:
            self.logger.error("openpyxl not installed. Please install: pip install openpyxl")
            return False
        except Exception as e:
            self.logger.error(f"Excel export failed: {e}")
            return False

    def export_to_csv(self, data: list, filepath: str) -> bool:
        try:
            if not data:
                return False
            keys = data[0].keys()
            with open(filepath, 'w', newline='', encoding='utf-8-sig') as f:
                writer = csv.DictWriter(f, fieldnames=keys)
                writer.writeheader()
                writer.writerows(data)
            self.logger.info(f"CSV report saved to {filepath}")
            return True
        except Exception as e:
            self.logger.error(f"CSV export failed: {e}")
            return False

    def export_to_pdf(self, data: list, filepath: str) -> bool:
        try:
            from fpdf import FPDF
            pdf = FPDF()
            pdf.add_page()
            pdf.add_font('DejaVu', '', 'DejaVuSans.ttf', uni=True)
            pdf.set_font('DejaVu', '', 12)
            pdf.cell(200, 10, txt="تقرير الأرشيف الإلكتروني", ln=1, align='C')
            pdf.ln(10)
            for row in data[:100]:
                line = f"{row.get('transaction_number', '')} - {row.get('title', '')}"
                pdf.cell(200, 10, txt=line.encode('utf-8').decode('latin-1'), ln=1)
            pdf.output(filepath)
            self.logger.info(f"PDF report saved to {filepath}")
            return True
        except Exception as e:
            self.logger.error(f"PDF export failed: {e}")
            return False