# -*- coding: utf-8 -*-
import shutil
import zipfile
import datetime
import os
from config.settings import Settings
from logs.log_manager import LogManager

class BackupService:
    def __init__(self):
        self.logger = LogManager()
    
    def create_backup(self, name: str = None) -> str:
        if not name:
            name = f"backup_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
        backup_path = Settings.BACKUP_DIR / f"{name}.zip"
        
        with zipfile.ZipFile(str(backup_path), 'w', zipfile.ZIP_DEFLATED) as zipf:
            if Settings.DB_PATH.exists():
                zipf.write(str(Settings.DB_PATH), arcname="database/archive.db")
            if Settings.UPLOADS_DIR.exists():
                for root, dirs, files in os.walk(str(Settings.UPLOADS_DIR)):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, str(Settings.BASE_DIR))
                        zipf.write(file_path, arcname)
        
        self.logger.info(f"Backup created: {backup_path}")
        return str(backup_path)
    
    def restore_backup(self, zip_path: str) -> bool:
        try:
            with zipfile.ZipFile(zip_path, 'r') as zipf:
                zipf.extractall(str(Settings.BASE_DIR))
            self.logger.info(f"Backup restored from {zip_path}")
            return True
        except Exception as e:
            self.logger.error(f"Restore failed: {e}")
            return False
    
    def list_backups(self):
        backups = []
        for f in Settings.BACKUP_DIR.glob("*.zip"):
            backups.append({
                'name': f.name,
                'path': str(f),
                'size': f.stat().st_size,
                'modified': datetime.datetime.fromtimestamp(f.stat().st_mtime)
            })
        return sorted(backups, key=lambda x: x['modified'], reverse=True)