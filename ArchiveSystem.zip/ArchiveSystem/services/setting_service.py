# -*- coding: utf-8 -*-
import shutil
import os
from pathlib import Path
from database.db_manager import DatabaseManager
from config.settings import Settings
from logs.log_manager import LogManager

class SettingService:
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
        self.logger = LogManager()

    def get(self, key: str, default=None):
        with self.db.get_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT value FROM system_settings WHERE key = ?", (key,))
            row = cur.fetchone()
            return row['value'] if row else default

    def set(self, key: str, value: str):
        with self.db.get_connection() as conn:
            cur = conn.cursor()
            cur.execute("INSERT OR REPLACE INTO system_settings (key, value) VALUES (?, ?)", (key, value))

    def get_archive_path(self) -> Path:
        saved = self.get("archive_root")
        default = Settings.DEFAULT_ARCHIVE_ROOT
        if saved:
            path = Path(saved)
            if path.exists() and os.access(path, os.W_OK):
                return path
            else:
                self.logger.warning(f"مسار الأرشيف المخزن {saved} غير صالح. استخدام الافتراضي.")
                return default
        return default

    def set_archive_path(self, path: str, update_existing: bool = False, old_path: Path = None):
        """حفظ مسار الأرشيف الجديد. إذا كان update_existing=True، فسيتم تحديث مسارات المرفقات."""
        new_path = Path(path)
        # التحقق من صلاحية المسار الجديد
        try:
            new_path.mkdir(parents=True, exist_ok=True)
            test_file = new_path / ".write_test"
            test_file.touch()
            test_file.unlink()
        except Exception as e:
            self.logger.error(f"المسار {path} غير صالح: {e}")
            raise ValueError(f"لا يمكن الكتابة في المسار المحدد: {e}")

        if update_existing and old_path and old_path.exists():
            # تحديث مسارات المرفقات في قاعدة البيانات
            count = self.update_attachment_paths(str(old_path), str(new_path))
            self.logger.info(f"تم تحديث {count} مرفق إلى المسار الجديد.")
        # حفظ المسار الجديد
        self.set("archive_root", str(new_path))
        Settings.ARCHIVE_ROOT = new_path
        self.logger.info(f"تم تعيين مسار الأرشيف إلى {new_path}")

    def update_attachment_paths(self, old_root: str, new_root: str) -> int:
        """تحديث مسارات المرفقات في قاعدة البيانات"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            # تحديث مسار المرفقات
            cursor.execute("""
                UPDATE attachments 
                SET filepath = REPLACE(filepath, ?, ?)
                WHERE filepath LIKE ?
            """, (old_root, new_root, f"{old_root}%"))
            count = cursor.rowcount
            # تحديث حقل archive_path في documents (إذا كان مخزناً)
            cursor.execute("""
                UPDATE documents 
                SET archive_path = REPLACE(archive_path, ?, ?)
                WHERE archive_path LIKE ?
            """, (old_root, new_root, f"{old_root}%"))
            self.logger.info(f"تم تحديث {count} مرفق و {cursor.rowcount} وثيقة")
            return count

    def migrate_archive(self, old_path: Path, new_path: Path, progress_callback=None) -> bool:
        """نقل الأرشيف من old_path إلى new_path باستخدام move"""
        if not old_path.exists():
            self.logger.warning(f"المسار القديم غير موجود: {old_path}")
            return False

        # منع النقل إذا كان المسار الجديد داخل المسار القديم
        try:
            if new_path.resolve().is_relative_to(old_path.resolve()):
                raise ValueError("لا يمكن نقل الأرشيف إلى مجلد فرعي داخله.")
        except AttributeError:
            # للإصدارات الأقدم من Python 3.9
            if str(new_path).startswith(str(old_path)):
                raise ValueError("لا يمكن نقل الأرشيف إلى مجلد فرعي داخله.")

        # التحقق من المساحة
        def get_free_space(path):
            stat = os.statvfs(path)
            return stat.f_frsize * stat.f_bfree
        try:
            total_size = sum(f.stat().st_size for f in old_path.rglob('*') if f.is_file())
            free_space = get_free_space(new_path.parent)
            if free_space < total_size:
                raise ValueError(f"مساحة غير كافية على القرص الهدف. تحتاج إلى {total_size // (1024**2)} MB.")
        except Exception as e:
            self.logger.error(f"خطأ في حساب المساحة: {e}")

        new_path.mkdir(parents=True, exist_ok=True)
        moved = 0
        total_files = sum(1 for _ in old_path.rglob('*') if _.is_file())

        for file_path in old_path.rglob('*'):
            if not file_path.is_file():
                continue
            relative = file_path.relative_to(old_path)
            dest_file = new_path / relative
            dest_file.parent.mkdir(parents=True, exist_ok=True)
            try:
                shutil.move(str(file_path), str(dest_file))
                moved += 1
                if progress_callback:
                    progress_callback(f"نقل {relative}... ({moved}/{total_files})")
            except Exception as e:
                self.logger.error(f"فشل نقل {file_path}: {e}")
                return False  # توقف عند أول خطأ

        self.logger.info(f"تم نقل {moved} ملف من {old_path} إلى {new_path}")
        return True

    def delete_old_archive(self, old_path: Path):
        try:
            shutil.rmtree(old_path)
            self.logger.info(f"تم حذف المجلد القديم: {old_path}")
        except Exception as e:
            self.logger.error(f"فشل حذف {old_path}: {e}")

    def repair_paths(self, old_root: str, new_root: str) -> int:
        """وظيفة لإصلاح المسارات يدوياً (إذا تم النقل يدوياً)"""
        return self.update_attachment_paths(old_root, new_root)