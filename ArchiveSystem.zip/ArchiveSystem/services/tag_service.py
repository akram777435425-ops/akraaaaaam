# -*- coding: utf-8 -*-
from database.db_manager import DatabaseManager
from logs.log_manager import LogManager

class TagService:
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
        self.logger = LogManager()
    
    def add_tag(self, name: str) -> int:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT OR IGNORE INTO tags (name) VALUES (?)", (name,))
            cursor.execute("SELECT id FROM tags WHERE name=?", (name,))
            row = cursor.fetchone()
            return row['id'] if row else None
    
    def get_all_tags(self):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM tags ORDER BY usage_count DESC")
            return [dict(row) for row in cursor.fetchall()]
    
    def assign_tag_to_document(self, doc_id: int, tag_name: str):
        tag_id = self.add_tag(tag_name)
        if tag_id:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("INSERT OR IGNORE INTO document_tags (document_id, tag_id) VALUES (?, ?)", (doc_id, tag_id))
                cursor.execute("UPDATE tags SET usage_count = usage_count + 1 WHERE id=?", (tag_id,))
    
    def get_document_tags(self, doc_id: int):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT t.name FROM tags t JOIN document_tags dt ON t.id = dt.tag_id WHERE dt.document_id=?", (doc_id,))
            return [row['name'] for row in cursor.fetchall()]