# -*- coding: utf-8 -*-
from database.db_manager import DatabaseManager
from logs.log_manager import LogManager

class ClassificationService:
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
        self.logger = LogManager()
    
    def add_category(self, name: str, parent_id: int = None, code: str = None) -> int:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO categories (name, parent_id, code) VALUES (?, ?, ?)",
                (name, parent_id, code)
            )
            self.logger.info(f"Category added: {name}")
            return cursor.lastrowid
    
    def get_categories_tree(self):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM categories ORDER BY parent_id, name")
            rows = cursor.fetchall()
            categories = [dict(row) for row in rows]
            tree = []
            category_dict = {c['id']: c for c in categories}
            for cat in categories:
                cat['children'] = []
                if cat['parent_id'] is None:
                    tree.append(cat)
                else:
                    parent = category_dict.get(cat['parent_id'])
                    if parent:
                        parent['children'].append(cat)
            return tree
    
    def suggest_category(self, keywords: str):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, name FROM categories WHERE name LIKE ? LIMIT 5", (f"%{keywords}%",))
            return [dict(row) for row in cursor.fetchall()]