# -*- coding: utf-8 -*-
from PyQt5.QtPrintSupport import QPrinter, QPrintDialog
from PyQt5.QtWidgets import QTextEdit, QMessageBox
from PyQt5.QtCore import Qt
from database.db_manager import DatabaseManager
from logs.log_manager import LogManager

class PrintService:
    def __init__(self, db_manager: DatabaseManager = None):
        self.db = db_manager
        self.logger = LogManager()
    
    def print_document(self, doc: dict, parent=None):
        """طباعة وثيقة واحدة"""
        if not doc:
            QMessageBox.warning(parent, "تنبيه", "لا توجد بيانات للطباعة")
            return False
        try:
            printer = QPrinter(QPrinter.HighResolution)
            dialog = QPrintDialog(printer, parent)
            if dialog.exec_() == QPrintDialog.Accepted:
                text_edit = QTextEdit()
                html_content = self._generate_document_html(doc)
                text_edit.setHtml(html_content)
                text_edit.document().print_(printer)
                self.logger.info(f"Printed document: {doc.get('transaction_number', '')}")
                return True
        except Exception as e:
            self.logger.error(f"Print error: {e}")
            QMessageBox.critical(parent, "خطأ", f"فشلت الطباعة: {e}")
        return False
    
    def print_multiple_documents(self, docs: list, parent=None):
        """طباعة عدة وثائق متتالية"""
        if not docs:
            QMessageBox.warning(parent, "تنبيه", "لا توجد وثائق للطباعة")
            return False
        printer = QPrinter(QPrinter.HighResolution)
        dialog = QPrintDialog(printer, parent)
        if dialog.exec_() == QPrintDialog.Accepted:
            combined_html = "<html dir='rtl'><head><meta charset='utf-8'></head><body>"
            for doc in docs:
                combined_html += self._generate_document_html(doc)
                combined_html += "<hr style='page-break-after: always;'>"
            combined_html += "</body></html>"
            text_edit = QTextEdit()
            text_edit.setHtml(combined_html)
            text_edit.document().print_(printer)
            self.logger.info(f"Printed {len(docs)} documents")
            return True
        return False
    
    def _generate_document_html(self, doc: dict) -> str:
        """توليد HTML لعرض بيانات الوثيقة"""
        return f"""
        <div style="font-family: 'Segoe UI', Arial; padding: 10px;">
            <h2 style="color: #1e3c72;">{doc.get('title', 'بدون عنوان')}</h2>
            <table width="100%" border="0" cellpadding="5">
                <tr><td width="30%"><strong>رقم المعاملة:</strong></td><td>{doc.get('transaction_number', '')}</td></tr>
                <tr><td><strong>رقم الوثيقة:</strong></td><td>{doc.get('doc_number', '')}</td></tr>
                <tr><td><strong>التاريخ:</strong></td><td>{doc.get('doc_date', '')}</td></tr>
                <tr><td><strong>المرسل:</strong></td><td>{doc.get('sender', '')}</td></tr>
                <tr><td><strong>المستلم:</strong></td><td>{doc.get('recipient', '')}</td></tr>
                <tr><td><strong>نوع المعاملة:</strong></td><td>{doc.get('incoming_outgoing', '')}</td></tr>
                <tr><td><strong>الحالة:</strong></td><td>{doc.get('doc_status', '')}</td></tr>
                <tr><td><strong>الأولوية:</strong></td><td>{doc.get('priority', '')}</td></tr>
                <tr><td><strong>مستوى السرية:</strong></td><td>{doc.get('confidentiality', 'عادي')}</td></tr>
                <tr><td><strong>المسار الأرشيفي:</strong></td><td>{doc.get('archive_path', '')}</td></tr>
                <tr><td valign="top"><strong>الوصف:</strong></td><td>{doc.get('description', '')}</td></tr>
                <tr><td valign="top"><strong>الكلمات المفتاحية:</strong></td><td>{doc.get('tags', '')}</td></tr>
            </table>
        </div>
        """