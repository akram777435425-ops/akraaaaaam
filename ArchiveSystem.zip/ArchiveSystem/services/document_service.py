# -*- coding: utf-8 -*-
import os
import shutil
import datetime
from pathlib import Path
from typing import Optional, List
from database.db_manager import DatabaseManager
from config.settings import Settings
from logs.log_manager import LogManager

class DocumentService:
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
        self.logger = LogManager()

    def generate_doc_number(self) -> str:
        year = datetime.datetime.now().year
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) as count FROM documents WHERE doc_number LIKE ?", (f"DOC-{year}-%",))
            count = cursor.fetchone()['count'] + 1
        return f"DOC-{year}-{count:06d}"

    def get_correspondent_code(self, correspondent_id):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT code FROM correspondents WHERE id=?", (correspondent_id,))
            row = cursor.fetchone()
            return row['code'] if row else "UNKNOWN"

    def get_correspondent_name(self, correspondent_id):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM correspondents WHERE id=?", (correspondent_id,))
            row = cursor.fetchone()
            return row['name'] if row else "بدون_جهة"

    def sanitize_folder_name(self, name):
        invalid_chars = r'<>:"/\|?*'
        for ch in invalid_chars:
            name = name.replace(ch, '')
        name = name.strip().replace(' ', '_')
        return name

    def build_archive_path(self, year, correspondent_id, transaction_type, transaction_number):
        correspondent_name = self.get_correspondent_name(correspondent_id)
        correspondent_name = self.sanitize_folder_name(correspondent_name)
        folder_type = "صادر" if transaction_type == "صادر" else "وارد"
        short_type = "ص" if transaction_type == "صادر" else "و"
        correspondent_code = self.get_correspondent_code(correspondent_id)
        year_suffix = str(year)[-2:]
        file_basename = f"{short_type}-{correspondent_code}-{transaction_number}-{year_suffix}"
        relative_path = Path(str(year)) / correspondent_name / folder_type
        full_path = Settings.ARCHIVE_ROOT / relative_path
        full_path.mkdir(parents=True, exist_ok=True)
        return relative_path, file_basename, full_path

    def get_unique_filename(self, folder_path, base_name, original_ext):
        candidate = f"{base_name}{original_ext}"
        counter = 1
        while (folder_path / candidate).exists():
            candidate = f"{base_name}({counter}){original_ext}"
            counter += 1
        return candidate

    def add_document(self, data: dict, attachments_paths: list = None) -> Optional[int]:
        try:
            year = data.get('year', datetime.datetime.now().year)
            transaction_number = data.get('transaction_number')
            transaction_type = data.get('incoming_outgoing')
            correspondent_id = data.get('correspondent_id')
            if not correspondent_id:
                raise ValueError("الجهة الخارجية مطلوبة لإنشاء المسار الأرشيفي")
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                # التحقق من تكرار رقم المعاملة
                cursor.execute("""
                    SELECT id FROM documents 
                    WHERE transaction_number = ? AND year = ? AND incoming_outgoing = ?
                """, (transaction_number, year, transaction_type))
                if cursor.fetchone():
                    raise ValueError(f"رقم المعاملة {transaction_number} مكرر لنفس السنة {year} ونفس النوع {transaction_type}")
                data['doc_number'] = self.generate_doc_number()
                data['added_date'] = datetime.datetime.now()
                data['year'] = year
                columns = ', '.join(data.keys())
                placeholders = ', '.join(['?' for _ in data])
                cursor.execute(f"INSERT INTO documents ({columns}) VALUES ({placeholders})", list(data.values()))
                doc_id = cursor.lastrowid
                if attachments_paths:
                    rel_path, base_name, full_path = self.build_archive_path(
                        year, correspondent_id, transaction_type, transaction_number
                    )
                    archive_path_str = str(rel_path / base_name)
                    cursor.execute("UPDATE documents SET archive_path=? WHERE id=?", (archive_path_str, doc_id))
                    for file_path in attachments_paths:
                        original_ext = os.path.splitext(file_path)[1]
                        unique_name = self.get_unique_filename(full_path, base_name, original_ext)
                        dest_path = full_path / unique_name
                        # استخدام move بدلاً من copy2 (أسرع ويوفر مساحة)
                        shutil.move(file_path, str(dest_path))
                        cursor.execute(
                            "INSERT INTO attachments (document_id, filename, filepath, filetype, filesize, uploaded_by) VALUES (?, ?, ?, ?, ?, ?)",
                            (doc_id, unique_name, str(dest_path), original_ext, os.path.getsize(dest_path), data['added_by'])
                        )
                    self.logger.info(f"Document added with attachments: {data['doc_number']}")
                else:
                    self.logger.info(f"Document added without attachments: {data['doc_number']}")
                return doc_id
        except Exception as e:
            self.logger.error(f"Error adding document: {e}")
            raise

    def update_document(self, doc_id: int, data: dict, new_attachments_paths: list = None) -> bool:
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                transaction_number = data.get('transaction_number')
                year = data.get('year')
                transaction_type = data.get('incoming_outgoing')
                cursor.execute("""
                    SELECT id FROM documents 
                    WHERE transaction_number = ? AND year = ? AND incoming_outgoing = ? AND id != ?
                """, (transaction_number, year, transaction_type, doc_id))
                if cursor.fetchone():
                    raise ValueError(f"رقم المعاملة {transaction_number} مكرر لنفس السنة {year} ونفس النوع {transaction_type}")
                data['modified_date'] = datetime.datetime.now()
                set_clause = ', '.join([f"{k}=?" for k in data.keys()])
                cursor.execute(f"UPDATE documents SET {set_clause} WHERE id=?", list(data.values()) + [doc_id])
                if new_attachments_paths:
                    cursor.execute("SELECT year, correspondent_id, incoming_outgoing, transaction_number FROM documents WHERE id=?", (doc_id,))
                    doc = cursor.fetchone()
                    if doc:
                        rel_path, base_name, full_path = self.build_archive_path(
                            doc['year'], doc['correspondent_id'], doc['incoming_outgoing'], doc['transaction_number']
                        )
                        for file_path in new_attachments_paths:
                            original_ext = os.path.splitext(file_path)[1]
                            unique_name = self.get_unique_filename(full_path, base_name, original_ext)
                            dest_path = full_path / unique_name
                            shutil.move(file_path, str(dest_path))
                            cursor.execute(
                                "INSERT INTO attachments (document_id, filename, filepath, filetype, filesize, uploaded_by) VALUES (?, ?, ?, ?, ?, ?)",
                                (doc_id, unique_name, str(dest_path), original_ext, os.path.getsize(dest_path), data.get('modified_by'))
                            )
                self.logger.info(f"Document {doc_id} updated")
                return cursor.rowcount > 0
        except Exception as e:
            self.logger.error(f"Error updating document: {e}")
            raise

    def delete_document(self, doc_id: int, hard: bool = False) -> bool:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            if hard:
                attachments = self.get_attachments(doc_id)
                for att in attachments:
                    if os.path.exists(att['filepath']):
                        os.remove(att['filepath'])
                cursor.execute("DELETE FROM attachments WHERE document_id=?", (doc_id,))
                cursor.execute("DELETE FROM document_tags WHERE document_id=?", (doc_id,))
                cursor.execute("DELETE FROM tasks WHERE document_id=?", (doc_id,))
                cursor.execute("DELETE FROM notes WHERE document_id=?", (doc_id,))
                cursor.execute("DELETE FROM documents WHERE id=?", (doc_id,))
                self.logger.info(f"Document {doc_id} hard deleted")
            else:
                cursor.execute("UPDATE documents SET is_archived=1, archive_date=? WHERE id=?", (datetime.datetime.now(), doc_id))
                self.logger.info(f"Document {doc_id} archived")
            return cursor.rowcount > 0

    def restore_document(self, doc_id: int) -> bool:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE documents SET is_archived=0, restored_date=? WHERE id=?", (datetime.datetime.now(), doc_id))
            self.logger.info(f"Document {doc_id} restored")
            return cursor.rowcount > 0

    def get_document(self, doc_id: int) -> Optional[dict]:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM documents WHERE id=?", (doc_id,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def get_all_documents(self, archived: bool = False, limit: int = 100, offset: int = 0):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT d.id, d.doc_number, d.transaction_number, d.title, d.doc_date,
                       d.sender_id, d.recipient_id, d.doc_type, d.doc_status, d.priority,
                       d.incoming_outgoing, d.tags, d.is_archived, d.archive_date, d.restored_date,
                       s.name as sender_name, 
                       r.name as recipient_name,
                       c.name as correspondent_name
                FROM documents d
                LEFT JOIN contacts s ON d.sender_id = s.id
                LEFT JOIN contacts r ON d.recipient_id = r.id
                LEFT JOIN correspondents c ON d.correspondent_id = c.id
                WHERE d.is_archived = ?
                ORDER BY d.added_date DESC
                LIMIT ? OFFSET ?
            """, (1 if archived else 0, limit, offset))
            return [dict(row) for row in cursor.fetchall()]

    def get_attachments(self, doc_id: int):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM attachments WHERE document_id=?", (doc_id,))
            return [dict(row) for row in cursor.fetchall()]

    def delete_attachment(self, attachment_id: int) -> bool:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT filepath FROM attachments WHERE id=?", (attachment_id,))
            row = cursor.fetchone()
            if row and os.path.exists(row['filepath']):
                os.remove(row['filepath'])
            cursor.execute("DELETE FROM attachments WHERE id=?", (attachment_id,))
            return cursor.rowcount > 0