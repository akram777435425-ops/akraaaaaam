# -*- coding: utf-8 -*-
import hashlib
import datetime
from database.db_manager import DatabaseManager
from logs.log_manager import LogManager

class AuthService:
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
        self.logger = LogManager()

    @staticmethod
    def _hash_password(password: str) -> str:
        return hashlib.sha256(password.encode('utf-8')).hexdigest()

    def authenticate(self, username: str, password: str):
        hashed = self._hash_password(password.strip())
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT id, username, full_name, email, role, is_active FROM users WHERE username = ? AND password = ?",
                (username.strip(), hashed)
            )
            user = cursor.fetchone()
            if user and user['is_active'] == 1:
                cursor.execute(
                    "UPDATE users SET last_login = ? WHERE id = ?",
                    (datetime.datetime.now(), user['id'])
                )
                self.logger.info(f"User {username} logged in")
                return dict(user)
            self.logger.warning(f"Failed login for {username}")
            return None

    def change_password(self, user_id: int, old_password: str, new_password: str) -> bool:
        old_hashed = self._hash_password(old_password.strip())
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT password FROM users WHERE id = ?", (user_id,))
            row = cursor.fetchone()
            if not row or row['password'] != old_hashed:
                return False
            new_hashed = self._hash_password(new_password.strip())
            cursor.execute("UPDATE users SET password = ? WHERE id = ?", (new_hashed, user_id))
            self.logger.info(f"Password changed for user {user_id}")
            return True

    def logout(self, user_id: int):
        self.logger.info(f"User {user_id} logged out")