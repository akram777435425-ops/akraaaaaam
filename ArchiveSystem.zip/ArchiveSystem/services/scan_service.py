# -*- coding: utf-8 -*-
import tempfile
import os
from PyQt5.QtWidgets import QMessageBox
from logs.log_manager import LogManager

class ScanService:
    def __init__(self):
        self.logger = LogManager()
        self.scanner_available = False
        try:
            import comtypes.client
            self.wia = comtypes.client.CreateObject("WIA.CommonDialog")
            self.scanner_available = True
            self.logger.info("WIA scanner available")
        except Exception as e:
            self.logger.warning(f"WIA not available: {e}")
    
    def scan_document(self, parent_widget=None):
        if not self.scanner_available:
            if parent_widget:
                QMessageBox.warning(parent_widget, "خطأ", "الماسح الضوئي غير متوفر على هذا النظام.\nتأكد من تثبيت برامج تشغيل الماسح الضوئي.")
            return None
        try:
            import comtypes.client
            wia = comtypes.client.CreateObject("WIA.CommonDialog")
            image = wia.ShowAcquireImage()
            if image:
                temp_file = tempfile.NamedTemporaryFile(suffix=".jpg", delete=False)
                image.SaveFile(temp_file.name)
                self.logger.info(f"Scanned image saved to {temp_file.name}")
                return temp_file.name
        except Exception as e:
            self.logger.error(f"Scan error: {e}")
            if parent_widget:
                QMessageBox.warning(parent_widget, "خطأ", f"فشل المسح: {e}")
        return None
    
    def convert_to_pdf(self, image_paths: list, output_pdf: str) -> bool:
        try:
            from PIL import Image
            images = []
            for img_path in image_paths:
                images.append(Image.open(img_path).convert('RGB'))
            if images:
                images[0].save(output_pdf, save_all=True, append_images=images[1:])
                return True
        except Exception as e:
            self.logger.error(f"PDF conversion failed: {e}")
        return False