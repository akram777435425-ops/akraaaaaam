# -*- coding: utf-8 -*-
from database.db_manager import DatabaseManager
from logs.log_manager import LogManager

class CorrespondenceService:
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
        self.logger = LogManager()
    
    def add_correspondence(self, data: dict) -> int:
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO correspondences (doc_id, from_entity, to_entity, subject, content, sent_date, received_date, status, tracking_number) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (data.get('doc_id'), data.get('from_entity'), data.get('to_entity'), data.get('subject'), data.get('content'), data.get('sent_date'), data.get('received_date'), data.get('status'), data.get('tracking_number'))
            )
            self.logger.info(f"Correspondence added for document {data.get('doc_id')}")
            return cursor.lastrowid
    
    def get_correspondence_by_document(self, doc_id: int):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM correspondences WHERE doc_id=?", (doc_id,))
            return [dict(row) for row in cursor.fetchall()]
    
    def update_status(self, corr_id: int, status: str):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE correspondences SET status=? WHERE id=?", (status, corr_id))