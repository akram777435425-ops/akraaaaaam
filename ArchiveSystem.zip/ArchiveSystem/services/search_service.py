# -*- coding: utf-8 -*-
from database.db_manager import DatabaseManager
from logs.log_manager import LogManager

class SearchService:
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
        self.logger = LogManager()
    
    def full_text_search(self, keyword: str, filters: dict = None):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            query = """
                SELECT d.*, c.name as category_name, co.name as correspondent_name
                FROM documents d
                LEFT JOIN categories c ON d.category_id = c.id
                LEFT JOIN correspondents co ON d.correspondent_id = co.id
                WHERE (d.title LIKE ? OR d.doc_number LIKE ? OR d.transaction_number LIKE ? OR d.description LIKE ? OR d.tags LIKE ? OR d.sender LIKE ? OR d.recipient LIKE ?)
            """
            params = [f"%{keyword}%"] * 7
            
            if filters:
                if filters.get('doc_type'):
                    query += " AND d.doc_type = ?"
                    params.append(filters['doc_type'])
                if filters.get('doc_status'):
                    query += " AND d.doc_status = ?"
                    params.append(filters['doc_status'])
                if filters.get('category_id'):
                    query += " AND d.category_id = ?"
                    params.append(filters['category_id'])
                if filters.get('from_date') and filters.get('to_date'):
                    query += " AND d.doc_date BETWEEN ? AND ?"
                    params.extend([filters['from_date'], filters['to_date']])
                if filters.get('incoming_outgoing'):
                    query += " AND d.incoming_outgoing = ?"
                    params.append(filters['incoming_outgoing'])
                if filters.get('transaction_number'):
                    query += " AND d.transaction_number = ?"
                    params.append(filters['transaction_number'])
            
            query += " ORDER BY d.added_date DESC LIMIT 500"
            cursor.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]
    
    def advanced_search(self, criteria: dict):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            query = "SELECT * FROM documents WHERE 1=1"
            params = []
            
            if criteria.get('transaction_number'):
                query += " AND transaction_number = ?"
                params.append(criteria['transaction_number'])
            if criteria.get('doc_number'):
                query += " AND doc_number LIKE ?"
                params.append(f"%{criteria['doc_number']}%")
            if criteria.get('title'):
                query += " AND title LIKE ?"
                params.append(f"%{criteria['title']}%")
            if criteria.get('from_date') and criteria.get('to_date'):
                query += " AND doc_date BETWEEN ? AND ?"
                params.extend([criteria['from_date'], criteria['to_date']])
            if criteria.get('doc_type'):
                query += " AND doc_type = ?"
                params.append(criteria['doc_type'])
            if criteria.get('doc_status'):
                query += " AND doc_status = ?"
                params.append(criteria['doc_status'])
            if criteria.get('priority'):
                query += " AND priority = ?"
                params.append(criteria['priority'])
            if criteria.get('category_id'):
                query += " AND category_id = ?"
                params.append(criteria['category_id'])
            if criteria.get('incoming_outgoing'):
                query += " AND incoming_outgoing = ?"
                params.append(criteria['incoming_outgoing'])
            
            cursor.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]