# -*- coding: utf-8 -*-
from database.db_manager import DatabaseManager
from logs.log_manager import LogManager

class ContactService:
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
        self.logger = LogManager()
    
    def get_all_contacts(self):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, name, contact_type, code, phone, email, is_active FROM contacts ORDER BY name")
            return [dict(row) for row in cursor.fetchall()]
    
    def get_contacts_by_type(self, contact_type):
        """contact_type: 'sender', 'recipient', 'both'"""
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, name FROM contacts WHERE contact_type IN (?, 'both') AND is_active=1 ORDER BY name", (contact_type,))
            return [dict(row) for row in cursor.fetchall()]
    
    def add_contact(self, name, contact_type, code, phone, email, address, notes):
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO contacts (name, contact_type, code, phone, email, address, notes, is_active)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 1)
                """, (name, contact_type, code, phone, email, address, notes))
                self.logger.info(f"Contact added: {name}")
                return True
        except Exception as e:
            self.logger.error(f"Error adding contact: {e}")
            return False
    
    def update_contact(self, contact_id, name, contact_type, code, phone, email, address, notes, is_active):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE contacts SET name=?, contact_type=?, code=?, phone=?, email=?, address=?, notes=?, is_active=?
                WHERE id=?
            """, (name, contact_type, code, phone, email, address, notes, 1 if is_active else 0, contact_id))
            self.logger.info(f"Contact {contact_id} updated")
            return cursor.rowcount > 0
    
    def delete_contact(self, contact_id):
        with self.db.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) as cnt FROM documents WHERE sender_id=? OR recipient_id=?", (contact_id, contact_id))
            if cursor.fetchone()['cnt'] > 0:
                raise ValueError("لا يمكن حذف جهة اتصال مستخدمة في وثائق. قم بتعديل الوثائق أولاً.")
            cursor.execute("DELETE FROM contacts WHERE id=?", (contact_id,))
            self.logger.info(f"Contact {contact_id} deleted")
            return cursor.rowcount > 0