# -*- coding: utf-8 -*-
# ملاحظة: OCR يتطلب تثبيت Tesseract. هذا مجرد هيكل جاهز مع رسالة تنبيه.
import subprocess
import os
from logs.log_manager import LogManager

class OCRService:
    def __init__(self):
        self.logger = LogManager()
        self.available = False
        # محاولة اكتشاف Tesseract إذا كان مثبتاً
        try:
            result = subprocess.run(['tesseract', '--version'], capture_output=True, text=True)
            if result.returncode == 0:
                self.available = True
        except:
            pass
    
    def extract_text_from_image(self, image_path: str) -> str:
        if not self.available:
            self.logger.warning("Tesseract OCR not installed")
            return ""
        try:
            import pytesseract
            from PIL import Image
            image = Image.open(image_path)
            text = pytesseract.image_to_string(image, lang='ara+eng')
            return text
        except Exception as e:
            self.logger.error(f"OCR failed: {e}")
            return ""
    
    def extract_text_from_pdf(self, pdf_path: str) -> str:
        if not self.available:
            return ""
        try:
            from pdf2image import convert_from_path
            import pytesseract
            images = convert_from_path(pdf_path)
            text = ""
            for img in images:
                text += pytesseract.image_to_string(img, lang='ara+eng')
            return text
        except:
            return ""