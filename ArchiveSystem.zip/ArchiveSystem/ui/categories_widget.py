
# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from database.db_manager import DatabaseManager

class CategoriesWidget(QWidget):
    def __init__(self, db_manager: DatabaseManager):
        super().__init__()
        self.db_manager = db_manager
        self.init_ui()
        self.load_tree()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        toolbar = QHBoxLayout()
        self.add_btn = QPushButton("إضافة تصنيف")
        self.edit_btn = QPushButton("تعديل")
        self.delete_btn = QPushButton("حذف")
        toolbar.addWidget(self.add_btn)
        toolbar.addWidget(self.edit_btn)
        toolbar.addWidget(self.delete_btn)
        layout.addLayout(toolbar)
        
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["التصنيف", "الكود", "الوصف"])
        self.tree.setLayoutDirection(Qt.RightToLeft)
        layout.addWidget(self.tree)
        
        self.add_btn.clicked.connect(self.add_category)
        self.edit_btn.clicked.connect(self.edit_category)
        self.delete_btn.clicked.connect(self.delete_category)
    
    def load_tree(self):
        self.tree.clear()
        with self.db_manager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM categories ORDER BY parent_id, name")
            rows = cursor.fetchall()
            categories = [dict(row) for row in rows]
            nodes = {}
            for cat in categories:
                item = QTreeWidgetItem([cat['name'], cat.get('code', ''), cat.get('description', '')])
                item.setData(0, Qt.UserRole, cat['id'])
                nodes[cat['id']] = item
                if cat['parent_id'] is None:
                    self.tree.addTopLevelItem(item)
                else:
                    parent = nodes.get(cat['parent_id'])
                    if parent:
                        parent.addChild(item)
        self.tree.expandAll()
    
    def add_category(self):
        dialog = CategoryDialog(self.db_manager)
        if dialog.exec_():
            self.load_tree()
    
    def edit_category(self):
        item = self.tree.currentItem()
        if not item:
            return
        cat_id = item.data(0, Qt.UserRole)
        dialog = CategoryDialog(self.db_manager, cat_id)
        if dialog.exec_():
            self.load_tree()
    
    def delete_category(self):
        item = self.tree.currentItem()
        if not item:
            return
        cat_id = item.data(0, Qt.UserRole)
        confirm = QMessageBox.question(self, "تأكيد", "حذف التصنيف وجميع تصنيفاته الفرعية؟", QMessageBox.Yes|QMessageBox.No)
        if confirm == QMessageBox.Yes:
            with self.db_manager.get_connection() as conn:
                conn.execute("DELETE FROM categories WHERE id=?", (cat_id,))
            self.load_tree()

class CategoryDialog(QDialog):
    def __init__(self, db_manager, cat_id=None):
        super().__init__()
        self.db_manager = db_manager
        self.cat_id = cat_id
        self.setWindowTitle("تصنيف")
        self.setLayoutDirection(Qt.RightToLeft)
        layout = QFormLayout(self)
        self.name_edit = QLineEdit()
        self.code_edit = QLineEdit()
        self.desc_edit = QTextEdit()
        self.parent_combo = QComboBox()
        self.load_parents()
        layout.addRow("الاسم:", self.name_edit)
        layout.addRow("الكود:", self.code_edit)
        layout.addRow("التصنيف الأب:", self.parent_combo)
        layout.addRow("الوصف:", self.desc_edit)
        btns = QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel)
        btns.accepted.connect(self.save)
        btns.rejected.connect(self.reject)
        layout.addRow(btns)
        if cat_id:
            self.load_data()
    
    def load_parents(self):
        self.parent_combo.addItem("لا يوجد أب", None)
        with self.db_manager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, name FROM categories")
            for row in cursor.fetchall():
                if self.cat_id and row['id'] == self.cat_id:
                    continue
                self.parent_combo.addItem(row['name'], row['id'])
    
    def load_data(self):
        with self.db_manager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM categories WHERE id=?", (self.cat_id,))
            row = cursor.fetchone()
            if row:
                self.name_edit.setText(row['name'])
                self.code_edit.setText(row['code'] or '')
                self.desc_edit.setPlainText(row['description'] or '')
                if row['parent_id']:
                    idx = self.parent_combo.findData(row['parent_id'])
                    if idx >= 0:
                        self.parent_combo.setCurrentIndex(idx)
    
    def save(self):
        name = self.name_edit.text().strip()
        if not name:
            QMessageBox.warning(self, "تنبيه", "الاسم مطلوب")
            return
        parent_id = self.parent_combo.currentData()
        code = self.code_edit.text()
        desc = self.desc_edit.toPlainText()
        with self.db_manager.get_connection() as conn:
            cursor = conn.cursor()
            if self.cat_id:
                cursor.execute("UPDATE categories SET name=?, parent_id=?, code=?, description=? WHERE id=?", (name, parent_id, code, desc, self.cat_id))
            else:
                cursor.execute("INSERT INTO categories (name, parent_id, code, description) VALUES (?,?,?,?)", (name, parent_id, code, desc))
        self.accept()
