# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from services.backup_service import BackupService
import os

class BackupWidget(QWidget):
    def __init__(self, db_manager):
        super().__init__()
        self.db_manager = db_manager
        self.backup_service = BackupService()
        self.init_ui()
        self.refresh_list()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        btn_layout = QHBoxLayout()
        self.create_btn = QPushButton("إنشاء نسخة احتياطية يدوية")
        self.restore_btn = QPushButton("استعادة نسخة")
        self.delete_btn = QPushButton("حذف نسخة")
        btn_layout.addWidget(self.create_btn)
        btn_layout.addWidget(self.restore_btn)
        btn_layout.addWidget(self.delete_btn)
        layout.addLayout(btn_layout)
        
        self.backup_list = QListWidget()
        layout.addWidget(self.backup_list)
        
        self.create_btn.clicked.connect(self.create_backup)
        self.restore_btn.clicked.connect(self.restore_backup)
        self.delete_btn.clicked.connect(self.delete_backup)
    
    def refresh_list(self):
        self.backup_list.clear()
        backups = self.backup_service.list_backups()
        for b in backups:
            self.backup_list.addItem(f"{b['name']} - {b['modified'].strftime('%Y-%m-%d %H:%M')} - {b['size']//1024} KB")
            self.backup_list.item(self.backup_list.count()-1).setData(Qt.UserRole, b['path'])
    
    def create_backup(self):
        path = self.backup_service.create_backup()
        QMessageBox.information(self, "تم", f"تم إنشاء النسخة الاحتياطية في:\n{path}")
        self.refresh_list()
    
    def restore_backup(self):
        current = self.backup_list.currentItem()
        if not current:
            QMessageBox.warning(self, "تنبيه", "اختر نسخة احتياطية أولاً")
            return
        backup_path = current.data(Qt.UserRole)
        confirm = QMessageBox.question(self, "تأكيد", "سيتم استعادة البيانات من النسخة الاحتياطية. استمرار؟", QMessageBox.Yes|QMessageBox.No)
        if confirm == QMessageBox.Yes:
            if self.backup_service.restore_backup(backup_path):
                QMessageBox.information(self, "تم", "تمت الاستعادة بنجاح. يرجى إعادة تشغيل التطبيق.")
            else:
                QMessageBox.critical(self, "خطأ", "فشلت عملية الاستعادة")
    
    def delete_backup(self):
        current = self.backup_list.currentItem()
        if not current:
            return
        backup_path = current.data(Qt.UserRole)
        # تأكيد قبل الحذف
        confirm = QMessageBox.question(self, "تأكيد الحذف", f"هل تريد حذف النسخة الاحتياطية '{current.text()}'؟", QMessageBox.Yes|QMessageBox.No)
        if confirm == QMessageBox.Yes:
            os.remove(backup_path)
            self.refresh_list()
            QMessageBox.information(self, "تم", "تم حذف النسخة الاحتياطية")