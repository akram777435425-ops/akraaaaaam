# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt, QSettings, QThread, pyqtSignal
from config.settings import Settings
from services.setting_service import SettingService
from pathlib import Path

class MigrateThread(QThread):
    progress = pyqtSignal(str)
    finished = pyqtSignal(bool)

    def __init__(self, old_path, new_path, setting_service):
        super().__init__()
        self.old_path = old_path
        self.new_path = new_path
        self.setting_service = setting_service

    def run(self):
        def callback(msg):
            self.progress.emit(msg)
        success = self.setting_service.migrate_archive(self.old_path, self.new_path, callback)
        self.finished.emit(success)


class SettingsWidget(QWidget):
    def __init__(self, db_manager):
        super().__init__()
        self.db_manager = db_manager
        self.setting_service = SettingService(db_manager)
        self.settings = QSettings("ArchiveSystem", "Settings")
        self.init_ui()
        self.load_settings()

    def init_ui(self):
        layout = QVBoxLayout(self)
        tabs = QTabWidget()

        # ----- عام -----
        general_tab = QWidget()
        general_layout = QFormLayout(general_tab)
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["فاتح", "داكن"])
        self.lang_combo = QComboBox()
        self.lang_combo.addItems(["العربية", "English"])
        self.rtl_check = QCheckBox("تمكين RTL")
        self.rtl_check.setChecked(True)
        general_layout.addRow("المظهر:", self.theme_combo)
        general_layout.addRow("اللغة:", self.lang_combo)
        general_layout.addRow("اتجاه الواجهة:", self.rtl_check)
        tabs.addTab(general_tab, "عام")

        # ----- الأرشيف -----
        archive_tab = QWidget()
        archive_layout = QFormLayout(archive_tab)

        self.archive_path_edit = QLineEdit()
        self.archive_path_edit.setMinimumHeight(32)
        browse_btn = QPushButton("تصفح...")
        browse_btn.clicked.connect(self.browse_archive_path)

        path_layout = QHBoxLayout()
        path_layout.addWidget(self.archive_path_edit)
        path_layout.addWidget(browse_btn)
        archive_layout.addRow("مسار الأرشيف الجديد:", path_layout)

        self.migrate_checkbox = QCheckBox("نقل الملفات القديمة إلى المسار الجديد تلقائياً (قد يستغرق وقتاً)")
        self.migrate_checkbox.setChecked(True)
        archive_layout.addRow(self.migrate_checkbox)

        self.save_archive_btn = QPushButton("حفظ المسار ونقل الملفات")
        self.save_archive_btn.clicked.connect(self.save_archive_path)
        archive_layout.addRow(self.save_archive_btn)

        # إضافة زر إصلاح المسارات
        self.repair_btn = QPushButton("إصلاح مسارات المرفقات (بعد نقل يدوي)")
        self.repair_btn.clicked.connect(self.repair_paths)
        archive_layout.addRow(self.repair_btn)

        self.progress_label = QLabel("")
        self.progress_label.setWordWrap(True)
        archive_layout.addRow(self.progress_label)

        tabs.addTab(archive_tab, "الأرشيف")

        # ----- نسخ احتياطي -----
        backup_tab = QWidget()
        backup_layout = QFormLayout(backup_tab)
        self.auto_backup_check = QCheckBox("تفعيل النسخ الاحتياطي التلقائي")
        self.backup_interval = QSpinBox()
        self.backup_interval.setSuffix(" ساعة")
        self.backup_interval.setRange(1, 168)
        backup_layout.addRow(self.auto_backup_check)
        backup_layout.addRow("الفاصل الزمني:", self.backup_interval)
        tabs.addTab(backup_tab, "النسخ الاحتياطي")

        layout.addWidget(tabs)

        save_btn = QPushButton("حفظ الإعدادات العامة")
        save_btn.clicked.connect(self.save_settings)
        layout.addWidget(save_btn)

        self.migrate_thread = None

    def browse_archive_path(self):
        folder = QFileDialog.getExistingDirectory(self, "اختر مجلد الأرشيف الجديد", self.archive_path_edit.text())
        if folder:
            self.archive_path_edit.setText(folder)

    def save_archive_path(self):
        new_path_str = self.archive_path_edit.text().strip()
        if not new_path_str:
            QMessageBox.warning(self, "تنبيه", "يرجى تحديد مسار صحيح")
            return

        new_path = Path(new_path_str)
        old_path = self.setting_service.get_archive_path()

        if new_path == old_path:
            QMessageBox.information(self, "تنبيه", "المسار الجديد مطابق للمسار الحالي، لم يتم التغيير")
            return

        if self.migrate_checkbox.isChecked() and old_path.exists():
            # تأكيد النقل
            reply = QMessageBox.question(self, "تأكيد النقل",
                                         f"سيتم نقل جميع الملفات من:\n{old_path}\nإلى:\n{new_path}\n\nقد يستغرق هذا دقائق حسب حجم الأرشيف. هل تريد المتابعة؟",
                                         QMessageBox.Yes | QMessageBox.No)
            if reply != QMessageBox.Yes:
                return

            self.save_archive_btn.setEnabled(False)
            self.progress_label.setText("جاري نقل الملفات... يرجى الانتظار")

            # تشغيل النقل في خيط منفصل
            self.migrate_thread = MigrateThread(old_path, new_path, self.setting_service)
            self.migrate_thread.progress.connect(self.progress_label.setText)
            self.migrate_thread.finished.connect(lambda success: self.on_migration_finished(success, old_path, new_path))
            self.migrate_thread.start()
        else:
            # فقط حفظ المسار بدون نقل (تحديث المسارات فقط)
            try:
                self.setting_service.set_archive_path(new_path_str, update_existing=True, old_path=old_path)
                QMessageBox.information(self, "تم", "تم حفظ مسار الأرشيف وتحديث مسارات المرفقات.")
                self.load_settings()
            except Exception as e:
                QMessageBox.critical(self, "خطأ", str(e))

    def on_migration_finished(self, success, old_path, new_path):
        self.save_archive_btn.setEnabled(True)
        if success:
            try:
                # تحديث مسارات المرفقات في قاعدة البيانات
                count = self.setting_service.update_attachment_paths(str(old_path), str(new_path))
                # حفظ المسار الجديد في الإعدادات
                self.setting_service.set_archive_path(str(new_path), update_existing=False)
                self.progress_label.setText(f"اكتمل النقل. تم تحديث {count} مرفق.")
                QMessageBox.information(self, "انتهى النقل", f"تم نقل الملفات وتحديث {count} مسار مرفق بنجاح.")
                # عرض خيار حذف القديم
                reply = QMessageBox.question(self, "حذف القديم",
                                             f"هل تريد حذف المجلد القديم ({old_path})؟",
                                             QMessageBox.Yes | QMessageBox.No)
                if reply == QMessageBox.Yes:
                    self.setting_service.delete_old_archive(old_path)
            except Exception as e:
                QMessageBox.critical(self, "خطأ", f"حدث خطأ أثناء تحديث المسارات: {e}")
        else:
            QMessageBox.critical(self, "خطأ", "فشل نقل الملفات. تحقق من صلاحيات المسار الجديد ومساحة التخزين.")
            self.progress_label.setText("فشل النقل.")
        self.load_settings()

    def repair_paths(self):
        """إصلاح مسارات المرفقات يدوياً (بعد نقل يدوي)"""
        old_root = QInputDialog.getText(self, "إصلاح المسارات", "أدخل المسار القديم (قبل النقل):")[0]
        new_root = QInputDialog.getText(self, "إصلاح المسارات", "أدخل المسار الجديد (بعد النقل):")[0]
        if old_root and new_root:
            try:
                count = self.setting_service.repair_paths(old_root, new_root)
                QMessageBox.information(self, "تم", f"تم تحديث {count} مسار مرفق.")
                self.load_settings()
            except Exception as e:
                QMessageBox.critical(self, "خطأ", str(e))

    def load_settings(self):
        self.theme_combo.setCurrentText(self.settings.value("theme", "فاتح"))
        self.lang_combo.setCurrentText(self.settings.value("language", "العربية"))
        self.rtl_check.setChecked(self.settings.value("rtl", True, type=bool))
        self.auto_backup_check.setChecked(self.settings.value("auto_backup", False, type=bool))
        self.backup_interval.setValue(int(self.settings.value("backup_interval", 24)))
        # تحميل مسار الأرشيف المخزن
        current_archive = self.setting_service.get_archive_path()
        self.archive_path_edit.setText(str(current_archive))

    def save_settings(self):
        self.settings.setValue("theme", self.theme_combo.currentText())
        self.settings.setValue("language", self.lang_combo.currentText())
        self.settings.setValue("rtl", self.rtl_check.isChecked())
        self.settings.setValue("auto_backup", self.auto_backup_check.isChecked())
        self.settings.setValue("backup_interval", self.backup_interval.value())
        QMessageBox.information(self, "تم", "تم حفظ الإعدادات العامة.")