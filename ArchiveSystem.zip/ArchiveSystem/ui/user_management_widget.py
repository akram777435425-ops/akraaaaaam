
# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from controllers.user_controller import UserController
import hashlib

class UserManagementWidget(QWidget):
    def __init__(self, db_manager, current_user):
        super().__init__()
        self.db_manager = db_manager
        self.current_user = current_user
        self.controller = UserController(db_manager)
        self.init_ui()
        self.refresh_table()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        toolbar = QHBoxLayout()
        self.add_btn = QPushButton("إضافة مستخدم")
        self.edit_btn = QPushButton("تعديل")
        self.delete_btn = QPushButton("حذف")
        self.reset_pwd_btn = QPushButton("تغيير كلمة المرور")
        toolbar.addWidget(self.add_btn)
        toolbar.addWidget(self.edit_btn)
        toolbar.addWidget(self.delete_btn)
        toolbar.addWidget(self.reset_pwd_btn)
        layout.addLayout(toolbar)
        
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["اسم المستخدم", "الاسم الكامل", "البريد", "الدور", "نشط", "آخر دخول"])
        layout.addWidget(self.table)
        
        self.add_btn.clicked.connect(self.add_user)
        self.edit_btn.clicked.connect(self.edit_user)
        self.delete_btn.clicked.connect(self.delete_user)
        self.reset_pwd_btn.clicked.connect(self.change_password)
    
    def refresh_table(self):
        users = self.controller.get_all_users()
        self.table.setRowCount(len(users))
        for i, u in enumerate(users):
            self.table.setItem(i, 0, QTableWidgetItem(u['username']))
            self.table.setItem(i, 1, QTableWidgetItem(u['full_name'] or ''))
            self.table.setItem(i, 2, QTableWidgetItem(u['email'] or ''))
            self.table.setItem(i, 3, QTableWidgetItem(u['role']))
            self.table.setItem(i, 4, QTableWidgetItem("نعم" if u['is_active'] else "لا"))
            self.table.setItem(i, 5, QTableWidgetItem(u['last_login'] or ''))
            self.table.item(i, 0).setData(Qt.UserRole, u['id'])
    
    def add_user(self):
        dialog = UserDialog(self.db_manager)
        if dialog.exec_():
            data = dialog.get_data()
            self.controller.add_user(data['username'], data['password'], data['full_name'], data['email'], data['role'])
            self.refresh_table()
    
    def edit_user(self):
        row = self.table.currentRow()
        if row < 0:
            return
        user_id = self.table.item(row, 0).data(Qt.UserRole)
        username = self.table.item(row, 0).text()
        full_name = self.table.item(row, 1).text()
        email = self.table.item(row, 2).text()
        role = self.table.item(row, 3).text()
        is_active = self.table.item(row, 4).text() == "نعم"
        dialog = UserDialog(self.db_manager, user_id, username, full_name, email, role, is_active)
        if dialog.exec_():
            data = dialog.get_data()
            self.controller.update_user(user_id, data['full_name'], data['email'], data['role'], 1 if data['is_active'] else 0)
            self.refresh_table()
    
    def delete_user(self):
        row = self.table.currentRow()
        if row < 0:
            return
        user_id = self.table.item(row, 0).data(Qt.UserRole)
        confirm = QMessageBox.question(self, "تأكيد", "حذف المستخدم؟", QMessageBox.Yes|QMessageBox.No)
        if confirm == QMessageBox.Yes:
            self.controller.delete_user(user_id)
            self.refresh_table()
    
    def change_password(self):
        row = self.table.currentRow()
        if row < 0:
            return
        user_id = self.table.item(row, 0).data(Qt.UserRole)
        username = self.table.item(row, 0).text()
        new_pwd, ok = QInputDialog.getText(self, "تغيير كلمة المرور", f"كلمة المرور الجديدة للمستخدم {username}:", QLineEdit.Password)
        if ok and new_pwd:
            hashed = hashlib.sha256(new_pwd.encode()).hexdigest()
            with self.db_manager.get_connection() as conn:
                conn.execute("UPDATE users SET password=? WHERE id=?", (hashed, user_id))
            QMessageBox.information(self, "تم", "تم تغيير كلمة المرور")

class UserDialog(QDialog):
    def __init__(self, db_manager, user_id=None, username="", full_name="", email="", role="user", is_active=True):
        super().__init__()
        self.db_manager = db_manager
        self.user_id = user_id
        self.setWindowTitle("مستخدم")
        self.setLayoutDirection(Qt.RightToLeft)
        layout = QFormLayout(self)
        self.username_edit = QLineEdit(username)
        self.full_name_edit = QLineEdit(full_name)
        self.email_edit = QLineEdit(email)
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.Password)
        self.role_combo = QComboBox()
        self.role_combo.addItems(["user", "admin"])
        self.role_combo.setCurrentText(role)
        self.active_check = QCheckBox("نشط")
        self.active_check.setChecked(is_active)
        
        layout.addRow("اسم المستخدم:", self.username_edit)
        layout.addRow("الاسم الكامل:", self.full_name_edit)
        layout.addRow("البريد:", self.email_edit)
        if not user_id:
            layout.addRow("كلمة المرور:", self.password_edit)
        layout.addRow("الدور:", self.role_combo)
        layout.addRow(self.active_check)
        
        btns = QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addRow(btns)
    
    def get_data(self):
        return {
            'username': self.username_edit.text().strip(),
            'password': self.password_edit.text(),
            'full_name': self.full_name_edit.text().strip(),
            'email': self.email_edit.text().strip(),
            'role': self.role_combo.currentText(),
            'is_active': self.active_check.isChecked()
        }