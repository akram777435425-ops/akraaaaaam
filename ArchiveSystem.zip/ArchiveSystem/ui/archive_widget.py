# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt, QDate
from services.search_service import SearchService
from database.db_manager import DatabaseManager

class SearchWidget(QWidget):
    def __init__(self, db_manager: DatabaseManager):
        super().__init__()
        self.db_manager = db_manager
        self.search_service = SearchService(db_manager)
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(20)
        
        # شريط البحث السريع
        quick_group = QGroupBox("بحث سريع")
        quick_group.setStyleSheet("QGroupBox { font-weight: bold; }")
        quick_layout = QHBoxLayout()
        self.keyword_edit = QLineEdit()
        self.keyword_edit.setPlaceholderText("ابحث في العنوان، رقم المعاملة، الوصف، الوسوم...")
        self.keyword_edit.setMinimumHeight(35)
        self.keyword_edit.setStyleSheet("padding: 10px; border-radius: 10px; font-size: 14px;")
        search_btn = QPushButton("🔍 بحث")
        search_btn.setMinimumHeight(35)
        search_btn.setCursor(Qt.PointingHandCursor)
        search_btn.clicked.connect(self.quick_search)
        quick_layout.addWidget(self.keyword_edit)
        quick_layout.addWidget(search_btn)
        quick_group.setLayout(quick_layout)
        layout.addWidget(quick_group)
        
        # البحث المتقدم
        advanced_group = QGroupBox("بحث متقدم")
        advanced_group.setStyleSheet("QGroupBox { font-weight: bold; }")
        group_layout = QGridLayout()
        group_layout.setSpacing(15)
        
        self.transaction_number_edit = QLineEdit()
        self.transaction_number_edit.setMinimumHeight(32)
        self.doc_number_edit = QLineEdit()
        self.doc_number_edit.setMinimumHeight(32)
        self.title_edit = QLineEdit()
        self.title_edit.setMinimumHeight(32)
        self.from_date = QDateEdit()
        self.from_date.setMinimumHeight(32)
        self.from_date.setDate(QDate(2000,1,1))
        self.to_date = QDateEdit()
        self.to_date.setMinimumHeight(32)
        self.to_date.setDate(QDate.currentDate())
        self.type_combo = QComboBox()
        self.type_combo.setMinimumHeight(32)
        self.type_combo.addItems(["الكل", "عادي", "سري", "هام"])
        self.status_combo = QComboBox()
        self.status_combo.setMinimumHeight(32)
        self.status_combo.addItems(["الكل", "جديدة", "قيد التنفيذ", "مكتملة", "مرفوضة"])
        self.priority_combo = QComboBox()
        self.priority_combo.setMinimumHeight(32)
        self.priority_combo.addItems(["الكل", "عادية", "متوسطة", "عالية", "عاجلة"])
        self.category_combo = QComboBox()
        self.category_combo.setMinimumHeight(32)
        self.in_out_combo = QComboBox()
        self.in_out_combo.setMinimumHeight(32)
        self.in_out_combo.addItems(["الكل", "وارد", "صادر"])
        self.load_categories()
        
        # تطبيق ستايل موحد لجميع الحقول
        line_style = "QLineEdit, QComboBox, QDateEdit { padding: 8px; border-radius: 8px; border: 1px solid #ccc; font-size: 13px; }"
        self.setStyleSheet(line_style)
        
        group_layout.addWidget(QLabel("رقم المعاملة:"), 0,0)
        group_layout.addWidget(self.transaction_number_edit, 0,1)
        group_layout.addWidget(QLabel("رقم الوثيقة:"), 0,2)
        group_layout.addWidget(self.doc_number_edit, 0,3)
        group_layout.addWidget(QLabel("العنوان:"), 1,0)
        group_layout.addWidget(self.title_edit, 1,1)
        group_layout.addWidget(QLabel("من تاريخ:"), 1,2)
        group_layout.addWidget(self.from_date, 1,3)
        group_layout.addWidget(QLabel("إلى تاريخ:"), 2,0)
        group_layout.addWidget(self.to_date, 2,1)
        group_layout.addWidget(QLabel("النوع:"), 2,2)
        group_layout.addWidget(self.type_combo, 2,3)
        group_layout.addWidget(QLabel("الحالة:"), 3,0)
        group_layout.addWidget(self.status_combo, 3,1)
        group_layout.addWidget(QLabel("الأولوية:"), 3,2)
        group_layout.addWidget(self.priority_combo, 3,3)
        group_layout.addWidget(QLabel("التصنيف:"), 4,0)
        group_layout.addWidget(self.category_combo, 4,1)
        group_layout.addWidget(QLabel("وارد/صادر:"), 4,2)
        group_layout.addWidget(self.in_out_combo, 4,3)
        
        advanced_btn = QPushButton("🔎 بحث متقدم")
        advanced_btn.setMinimumHeight(40)
        advanced_btn.setCursor(Qt.PointingHandCursor)
        advanced_btn.setStyleSheet("background-color: #2c5a92; color: white; font-weight: bold;")
        advanced_btn.clicked.connect(self.advanced_search)
        group_layout.addWidget(advanced_btn, 5,0,1,4)
        
        advanced_group.setLayout(group_layout)
        layout.addWidget(advanced_group)
        
        # نتائج البحث
        result_group = QGroupBox("نتائج البحث")
        result_group.setStyleSheet("QGroupBox { font-weight: bold; }")
        self.result_table = QTableWidget()
        self.result_table.setColumnCount(9)
        self.result_table.setHorizontalHeaderLabels([
            "رقم المعاملة", "رقم الوثيقة", "العنوان", "التاريخ", "النوع", "الحالة", "الأولوية", "التصنيف", "نوع المعاملة"
        ])
        self.result_table.setAlternatingRowColors(True)
        self.result_table.setStyleSheet("""
            QTableWidget {
                alternate-background-color: #f8f9fc;
                selection-background-color: #d9e2ec;
                border-radius: 10px;
                font-size: 13px;
            }
            QHeaderView::section {
                background-color: #e9ecef;
                padding: 8px;
                font-weight: bold;
            }
        """)
        result_group.setLayout(QVBoxLayout())
        result_group.layout().addWidget(self.result_table)
        layout.addWidget(result_group)
    
    def load_categories(self):
        try:
            with self.db_manager.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT id, name FROM categories")
                self.category_combo.addItem("الكل", None)
                for row in cursor.fetchall():
                    self.category_combo.addItem(row['name'], row['id'])
        except Exception as e:
            print(f"Error loading categories: {e}")
    
    def quick_search(self):
        try:
            keyword = self.keyword_edit.text().strip()
            if not keyword:
                QMessageBox.warning(self, "تنبيه", "أدخل كلمة للبحث")
                return
            results = self.search_service.full_text_search(keyword)
            self.display_results(results)
        except Exception as e:
            QMessageBox.critical(self, "خطأ", f"حدث خطأ أثناء البحث: {e}")
    
    def advanced_search(self):
        try:
            criteria = {}
            if self.transaction_number_edit.text().strip():
                criteria['transaction_number'] = self.transaction_number_edit.text().strip()
            if self.doc_number_edit.text().strip():
                criteria['doc_number'] = self.doc_number_edit.text().strip()
            if self.title_edit.text().strip():
                criteria['title'] = self.title_edit.text().strip()
            criteria['from_date'] = self.from_date.date().toString("yyyy-MM-dd")
            criteria['to_date'] = self.to_date.date().toString("yyyy-MM-dd")
            if self.type_combo.currentText() != "الكل":
                criteria['doc_type'] = self.type_combo.currentText()
            if self.status_combo.currentText() != "الكل":
                criteria['doc_status'] = self.status_combo.currentText()
            if self.priority_combo.currentText() != "الكل":
                criteria['priority'] = self.priority_combo.currentText()
            cat_id = self.category_combo.currentData()
            if cat_id:
                criteria['category_id'] = cat_id
            if self.in_out_combo.currentText() != "الكل":
                criteria['incoming_outgoing'] = self.in_out_combo.currentText()
            results = self.search_service.advanced_search(criteria)
            self.display_results(results)
        except Exception as e:
            QMessageBox.critical(self, "خطأ", f"حدث خطأ أثناء البحث المتقدم: {e}")
    
    def display_results(self, results):
        self.result_table.setRowCount(len(results))
        for i, doc in enumerate(results):
            self.result_table.setItem(i, 0, QTableWidgetItem(str(doc.get('transaction_number', ''))))
            self.result_table.setItem(i, 1, QTableWidgetItem(doc.get('doc_number', '')))
            self.result_table.setItem(i, 2, QTableWidgetItem(doc.get('title', '')))
            self.result_table.setItem(i, 3, QTableWidgetItem(doc.get('doc_date', '')))
            self.result_table.setItem(i, 4, QTableWidgetItem(doc.get('doc_type', '')))
            self.result_table.setItem(i, 5, QTableWidgetItem(doc.get('doc_status', '')))
            self.result_table.setItem(i, 6, QTableWidgetItem(doc.get('priority', '')))
            self.result_table.setItem(i, 7, QTableWidgetItem(doc.get('category_name', '')))
            self.result_table.setItem(i, 8, QTableWidgetItem(doc.get('incoming_outgoing', '')))