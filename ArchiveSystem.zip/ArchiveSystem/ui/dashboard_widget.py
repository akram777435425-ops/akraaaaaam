# -*- coding: utf-8 -*-
import datetime
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt, QTimer, QDate, QPropertyAnimation, QEasingCurve, pyqtSignal
from PyQt5.QtChart import QChart, QChartView, QPieSeries, QPieSlice, QLineSeries, QBarSeries, QBarSet, QBarCategoryAxis, QValueAxis, QHorizontalBarSeries, QHorizontalPercentBarSeries
from PyQt5.QtGui import QPainter, QColor, QFont, QLinearGradient, QBrush, QPalette, QPixmap
from PyQt5.QtWidgets import QGraphicsDropShadowEffect
from controllers.dashboard_controller import DashboardController
from services.report_service import ReportService
from database.db_manager import DatabaseManager
from ui.help_dialog import HelpDialog

class AnimatedLabel(QLabel):
    """بطاقة رقمية متحركة"""
    valueChanged = pyqtSignal(int)
    def __init__(self, text="0", parent=None):
        super().__init__(text, parent)
        self.animation = QPropertyAnimation(self, b"value")
        self.animation.setDuration(800)
        self.animation.setEasingCurve(QEasingCurve.OutCubic)
        self._value = 0
        self.animation.valueChanged.connect(self._on_value_changed)

    @property
    def value(self):
        return self._value

    @value.setter
    def value(self, v):
        self._value = v
        self.setText(str(int(v)))

    def animate_to(self, target):
        self.animation.stop()
        self.animation.setStartValue(self._value)
        self.animation.setEndValue(float(target))
        self.animation.start()

    def _on_value_changed(self, val):
        self.value = val

class DashboardWidget(QWidget):
    def __init__(self, db_manager: DatabaseManager, user: dict):
        super().__init__()
        self.db_manager = db_manager
        self.user = user
        self.controller = DashboardController(db_manager)
        self.report_service = ReportService(db_manager)
        self.current_filter = "this_week"  # this_week, this_month, this_year
        self.custom_start_date = None
        self.custom_end_date = None
        self.init_ui()
        self.load_all_data()

    def init_ui(self):
        # خلفية متدرجة
        self.setAutoFillBackground(True)
        palette = self.palette()
        gradient = QLinearGradient(0, 0, 0, self.height())
        gradient.setColorAt(0, QColor(15, 30, 60))
        gradient.setColorAt(1, QColor(25, 50, 90))
        palette.setBrush(QPalette.Window, QBrush(gradient))
        self.setPalette(palette)

        # منطقة تمرير رئيسية
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")

        container = QWidget()
        container.setObjectName("container")
        container.setStyleSheet("#container { background: transparent; }")
        main_layout = QVBoxLayout(container)
        main_layout.setSpacing(25)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # شريط العنوان والأدوات
        title_layout = QHBoxLayout()
        title = QLabel("📊 لوحة التحكم الرئيسية")
        title.setStyleSheet("font-size: 28px; font-weight: bold; color: #ffffff; border-bottom: 2px solid #ffc107; padding-bottom: 5px;")
        title.setAlignment(Qt.AlignRight)
        title_layout.addWidget(title)
        help_btn = QPushButton("❓")
        help_btn.setFixedSize(35, 35)
        help_btn.setCursor(Qt.PointingHandCursor)
        help_btn.setToolTip("مساعدة")
        help_btn.setStyleSheet("""
            QPushButton { background-color: #ffc107; color: #1e3c72; border-radius: 18px; font-weight: bold; }
            QPushButton:hover { background-color: #ffca2c; }
        """)
        help_btn.clicked.connect(lambda: HelpDialog("dashboard", self).exec_())
        title_layout.addWidget(help_btn)
        title_layout.addStretch()

        # فلتر الوقت
        filter_label = QLabel("الفترة:")
        filter_label.setStyleSheet("color: white; font-weight: bold;")
        self.filter_combo = QComboBox()
        self.filter_combo.addItems(["آخر 7 أيام", "هذا الشهر", "هذا العام", "مخصص..."])
        self.filter_combo.setStyleSheet("""
            QComboBox { background-color: #2c3e50; color: white; padding: 5px; border-radius: 5px; }
            QComboBox::drop-down { border: none; }
        """)
        self.filter_combo.currentIndexChanged.connect(self.on_filter_changed)
        self.custom_date_btn = QPushButton("اختر تاريخين")
        self.custom_date_btn.setVisible(False)
        self.custom_date_btn.clicked.connect(self.choose_custom_dates)
        self.custom_date_btn.setStyleSheet("""
            QPushButton { background-color: #3498db; color: white; border-radius: 5px; padding: 5px 10px; }
        """)

        refresh_btn = QPushButton("🔄 تحديث")
        refresh_btn.setCursor(Qt.PointingHandCursor)
        refresh_btn.setStyleSheet("""
            QPushButton { background-color: #2ecc71; color: white; border-radius: 10px; padding: 8px 20px; font-weight: bold; }
            QPushButton:hover { background-color: #27ae60; }
        """)
        refresh_btn.clicked.connect(self.refresh_all)

        export_btn = QPushButton("📸 تصدير كصورة")
        export_btn.setCursor(Qt.PointingHandCursor)
        export_btn.setStyleSheet("""
            QPushButton { background-color: #e67e22; color: white; border-radius: 10px; padding: 8px 20px; font-weight: bold; }
            QPushButton:hover { background-color: #d35400; }
        """)
        export_btn.clicked.connect(self.export_dashboard_image)

        title_layout.addWidget(filter_label)
        title_layout.addWidget(self.filter_combo)
        title_layout.addWidget(self.custom_date_btn)
        title_layout.addWidget(refresh_btn)
        title_layout.addWidget(export_btn)
        main_layout.addLayout(title_layout)

        # صف البطاقات الرئيسية
        cards_layout = QHBoxLayout()
        cards_layout.setSpacing(20)
        self.total_card = self.create_stat_card("إجمالي الوثائق", "0", "#3498db", "📄")
        self.incoming_card = self.create_stat_card("الوارد", "0", "#2ecc71", "📥")
        self.outgoing_card = self.create_stat_card("الصادر", "0", "#e67e22", "📤")
        self.storage_card = self.create_stat_card("مساحة التخزين", "0 MB", "#9b59b6", "💾")
        cards_layout.addWidget(self.total_card)
        cards_layout.addWidget(self.incoming_card)
        cards_layout.addWidget(self.outgoing_card)
        cards_layout.addWidget(self.storage_card)
        main_layout.addLayout(cards_layout)

        # صف الإحصائيات السريعة
        quick_stats_layout = QHBoxLayout()
        self.today_docs_card = self.create_small_card("📅 اليوم", "0")
        self.latest_doc_card = self.create_small_card("📄 آخر وثيقة", "لا يوجد")
        quick_stats_layout.addWidget(self.today_docs_card)
        quick_stats_layout.addWidget(self.latest_doc_card)
        main_layout.addLayout(quick_stats_layout)

        # المخططات الأساسية (الصف الأول)
        row1 = QHBoxLayout()
        row1.setSpacing(20)

        # مخطط دائري (الحالات)
        pie_group = QGroupBox("توزيع حسب الحالة")
        pie_group.setStyleSheet(self.group_style())
        pie_layout = QVBoxLayout(pie_group)
        self.pie_chart_view = self.create_pie_chart()
        pie_layout.addWidget(self.pie_chart_view)
        row1.addWidget(pie_group, 1)

        # مخطط دائري ثانٍ (الأولوية)
        priority_group = QGroupBox("توزيع حسب الأولوية")
        priority_group.setStyleSheet(self.group_style())
        priority_layout = QVBoxLayout(priority_group)
        self.priority_chart_view = self.create_priority_chart()
        priority_layout.addWidget(self.priority_chart_view)
        row1.addWidget(priority_group, 1)

        # مخطط خطي (الاتجاه)
        line_group = QGroupBox("اتجاه الوثائق المضافة")
        line_group.setStyleSheet(self.group_style())
        line_layout = QVBoxLayout(line_group)
        self.line_chart_view = self.create_line_chart()
        line_layout.addWidget(self.line_chart_view)
        row1.addWidget(line_group, 1)

        main_layout.addLayout(row1)

        # صف المخططات الثانوية
        row2 = QHBoxLayout()
        row2.setSpacing(20)

        # مخطط عمودي (وارد/صادر)
        bar_group = QGroupBox("المقارنة (وارد/صادر)")
        bar_group.setStyleSheet(self.group_style())
        bar_layout = QVBoxLayout(bar_group)
        self.bar_chart_view = self.create_bar_chart()
        bar_layout.addWidget(self.bar_chart_view)
        row2.addWidget(bar_group, 2)

        # أكثر التصنيفات استخداماً (شريطي أفقي)
        cat_group = QGroupBox("أكثر التصنيفات استخداماً")
        cat_group.setStyleSheet(self.group_style())
        cat_layout = QVBoxLayout(cat_group)
        self.cat_chart_view = self.create_category_chart()
        cat_layout.addWidget(self.cat_chart_view)
        row2.addWidget(cat_group, 1)

        main_layout.addLayout(row2)

        # جدول آخر الأنشطة
        activity_group = QGroupBox("آخر الأنشطة")
        activity_group.setStyleSheet(self.group_style())
        activity_layout = QVBoxLayout(activity_group)
        self.activities_table = QTableWidget()
        self.activities_table.setColumnCount(4)
        self.activities_table.setHorizontalHeaderLabels(["المستخدم", "الإجراء", "التفاصيل", "التاريخ"])
        self.activities_table.horizontalHeader().setStretchLastSection(True)
        self.activities_table.setAlternatingRowColors(True)
        self.activities_table.setStyleSheet("""
            QTableWidget {
                alternate-background-color: #f8f9fc;
                selection-background-color: #d9e2ec;
                gridline-color: #e2e8f0;
                border-radius: 10px;
                background-color: white;
            }
            QHeaderView::section { background-color: #e9ecef; padding: 8px; font-weight: bold; }
        """)
        activity_layout.addWidget(self.activities_table)
        main_layout.addWidget(activity_group)

        scroll.setWidget(container)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(scroll)

        # تحديث تلقائي كل 60 ثانية
        self.timer = QTimer()
        self.timer.timeout.connect(self.refresh_all)
        self.timer.start(60000)

    def group_style(self):
        return """
            QGroupBox {
                font-weight: bold;
                font-size: 14px;
                border: 1px solid #cbd5e1;
                border-radius: 12px;
                margin-top: 12px;
                padding-top: 10px;
                background-color: rgba(255,255,255,0.95);
            }
            QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }
        """

    def create_stat_card(self, title, value, color, icon):
        card = QFrame()
        card.setStyleSheet(f"""
            QFrame {{
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 {color}, stop:1 {color}80);
                border-radius: 20px;
                padding: 15px;
            }}
        """)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(15)
        shadow.setOffset(0, 5)
        shadow.setColor(QColor(0,0,0,60))
        card.setGraphicsEffect(shadow)

        layout = QVBoxLayout(card)
        top = QHBoxLayout()
        icon_lbl = QLabel(icon)
        icon_lbl.setStyleSheet(f"font-size: 38px;")
        title_lbl = QLabel(title)
        title_lbl.setStyleSheet("font-size: 14px; color: #f8f9fc;")
        top.addWidget(icon_lbl)
        top.addWidget(title_lbl)
        top.addStretch()
        layout.addLayout(top)
        val_lbl = AnimatedLabel("0")
        val_lbl.setStyleSheet(f"font-size: 32px; font-weight: bold; color: white;")
        val_lbl.setAlignment(Qt.AlignRight)
        layout.addWidget(val_lbl)
        card.value_label = val_lbl
        return card

    def create_small_card(self, title, value):
        card = QFrame()
        card.setStyleSheet("""
            QFrame { background: rgba(255,255,255,0.2); border-radius: 15px; padding: 8px; }
        """)
        layout = QHBoxLayout(card)
        title_lbl = QLabel(title)
        title_lbl.setStyleSheet("color: white; font-weight: bold;")
        self.val_lbl = QLabel(value)
        self.val_lbl.setStyleSheet("color: #ffc107; font-weight: bold; font-size: 16px;")
        layout.addWidget(title_lbl)
        layout.addStretch()
        layout.addWidget(self.val_lbl)
        card.value_label = self.val_lbl
        return card

    def create_pie_chart(self):
        series = QPieSeries()
        chart = QChart()
        chart.addSeries(series)
        chart.setAnimationOptions(QChart.SeriesAnimations)
        chart.setLayoutDirection(Qt.RightToLeft)
        chart.setBackgroundVisible(False)
        chart.legend().setVisible(True)
        chart.legend().setAlignment(Qt.AlignBottom)
        chart_view = QChartView(chart)
        chart_view.setRenderHint(QPainter.Antialiasing)
        chart_view.setMinimumHeight(300)
        return chart_view

    def create_priority_chart(self):
        series = QPieSeries()
        chart = QChart()
        chart.addSeries(series)
        chart.setAnimationOptions(QChart.SeriesAnimations)
        chart.setLayoutDirection(Qt.RightToLeft)
        chart.setBackgroundVisible(False)
        chart_view = QChartView(chart)
        chart_view.setRenderHint(QPainter.Antialiasing)
        chart_view.setMinimumHeight(300)
        return chart_view

    def create_line_chart(self):
        series = QLineSeries()
        series.setName("الوثائق")
        chart = QChart()
        chart.addSeries(series)
        chart.setAnimationOptions(QChart.SeriesAnimations)
        chart.setBackgroundVisible(False)
        axis_x = QBarCategoryAxis()
        axis_x.setLabelsColor(QColor("#2c3e50"))
        chart.addAxis(axis_x, Qt.AlignBottom)
        series.attachAxis(axis_x)
        axis_y = QValueAxis()
        axis_y.setTitleText("العدد")
        chart.addAxis(axis_y, Qt.AlignLeft)
        series.attachAxis(axis_y)
        chart_view = QChartView(chart)
        chart_view.setRenderHint(QPainter.Antialiasing)
        chart_view.setMinimumHeight(300)
        return chart_view

    def create_bar_chart(self):
        series = QBarSeries()
        incoming = QBarSet("وارد")
        outgoing = QBarSet("صادر")
        incoming.setColor(QColor("#2ecc71"))
        outgoing.setColor(QColor("#e67e22"))
        series.append(incoming)
        series.append(outgoing)
        chart = QChart()
        chart.addSeries(series)
        chart.setAnimationOptions(QChart.SeriesAnimations)
        chart.setBackgroundVisible(False)
        axis_x = QBarCategoryAxis()
        axis_x.setLabelsColor(QColor("#2c3e50"))
        chart.addAxis(axis_x, Qt.AlignBottom)
        series.attachAxis(axis_x)
        axis_y = QValueAxis()
        axis_y.setTitleText("العدد")
        chart.addAxis(axis_y, Qt.AlignLeft)
        series.attachAxis(axis_y)
        chart_view = QChartView(chart)
        chart_view.setRenderHint(QPainter.Antialiasing)
        chart_view.setMinimumHeight(300)
        return chart_view

    def create_category_chart(self):
        series = QBarSeries()
        chart = QChart()
        chart.addSeries(series)
        chart.setAnimationOptions(QChart.SeriesAnimations)
        chart.setBackgroundVisible(False)
        axis_x = QBarCategoryAxis()
        axis_x.setLabelsColor(QColor("#2c3e50"))
        chart.addAxis(axis_x, Qt.AlignBottom)
        series.attachAxis(axis_x)
        axis_y = QValueAxis()
        axis_y.setTitleText("عدد الوثائق")
        chart.addAxis(axis_y, Qt.AlignLeft)
        series.attachAxis(axis_y)
        chart_view = QChartView(chart)
        chart_view.setRenderHint(QPainter.Antialiasing)
        chart_view.setMinimumHeight(300)
        return chart_view

    def on_filter_changed(self, idx):
        text = self.filter_combo.currentText()
        if text == "مخصص...":
            self.custom_date_btn.setVisible(True)
            self.choose_custom_dates()
        else:
            self.custom_date_btn.setVisible(False)
            if text == "آخر 7 أيام":
                self.custom_start_date = QDate.currentDate().addDays(-6)
                self.custom_end_date = QDate.currentDate()
            elif text == "هذا الشهر":
                self.custom_start_date = QDate.currentDate().addDays(1 - QDate.currentDate().day())
                self.custom_end_date = QDate.currentDate()
            elif text == "هذا العام":
                self.custom_start_date = QDate(QDate.currentDate().year(), 1, 1)
                self.custom_end_date = QDate.currentDate()
            self.refresh_all()

    def choose_custom_dates(self):
        start, ok1 = QInputDialog.getText(self, "تاريخ البداية", "أدخل تاريخ البداية (YYYY-MM-DD):")
        end, ok2 = QInputDialog.getText(self, "تاريخ النهاية", "أدخل تاريخ النهاية (YYYY-MM-DD):")
        if ok1 and ok2:
            try:
                self.custom_start_date = QDate.fromString(start, "yyyy-MM-dd")
                self.custom_end_date = QDate.fromString(end, "yyyy-MM-dd")
                self.refresh_all()
            except:
                QMessageBox.warning(self, "خطأ", "صيغة التاريخ غير صحيحة")

    def get_date_filter_condition(self):
        if self.custom_start_date and self.custom_end_date:
            return f"doc_date BETWEEN '{self.custom_start_date.toString('yyyy-MM-dd')}' AND '{self.custom_end_date.toString('yyyy-MM-dd')}'"
        return "1=1"

    def load_stats(self):
        try:
            stats = self.controller.get_stats()
            self.total_card.value_label.animate_to(stats.get('total_documents', 0))
            self.incoming_card.value_label.animate_to(stats.get('incoming_count', 0))
            self.outgoing_card.value_label.animate_to(stats.get('outgoing_count', 0))
            self.storage_card.value_label.animate_to(round(stats.get('storage_used_mb', 0), 1))
        except: pass
        try:
            with self.db_manager.get_connection() as conn:
                cur = conn.cursor()
                cur.execute("SELECT COUNT(*) FROM documents WHERE DATE(added_date)=DATE('now')")
                today_cnt = cur.fetchone()[0]
                self.today_docs_card.value_label.setText(str(today_cnt))
                cur.execute("SELECT title FROM documents ORDER BY added_date DESC LIMIT 1")
                last = cur.fetchone()
                self.latest_doc_card.value_label.setText(last[0] if last else "لا يوجد")
                cur.execute("SELECT username, action, details, timestamp FROM activity_log ORDER BY timestamp DESC LIMIT 15")
                rows = cur.fetchall()
                self.activities_table.setRowCount(len(rows))
                for i, r in enumerate(rows):
                    self.activities_table.setItem(i,0,QTableWidgetItem(r[0]))
                    self.activities_table.setItem(i,1,QTableWidgetItem(r[1]))
                    self.activities_table.setItem(i,2,QTableWidgetItem(r[2] or ""))
                    self.activities_table.setItem(i,3,QTableWidgetItem(r[3]))
        except Exception as e:
            print("Activities error", e)

    def load_charts(self):
        date_filter = self.get_date_filter_condition()
        with self.db_manager.get_connection() as conn:
            cur = conn.cursor()
            # Pie: status
            cur.execute(f"SELECT doc_status, COUNT(*) FROM documents WHERE {date_filter} GROUP BY doc_status")
            data = cur.fetchall()
            series = self.pie_chart_view.chart().series()[0]
            series.clear()
            colors = ["#3498db","#f39c12","#2ecc71","#e74c3c"]
            for i, (st, cnt) in enumerate(data):
                sl = series.append(st or "غير محدد", cnt)
                if sl: sl.setBrush(QColor(colors[i%4]))
            # Priority
            cur.execute(f"SELECT priority, COUNT(*) FROM documents WHERE {date_filter} GROUP BY priority")
            pdata = cur.fetchall()
            pseries = self.priority_chart_view.chart().series()[0]
            pseries.clear()
            pcolors = ["#e67e22","#f1c40f","#2ecc71","#95a5a6"]
            for i, (pr, cnt) in enumerate(pdata):
                sl = pseries.append(pr or "غير محدد", cnt)
                if sl: sl.setBrush(QColor(pcolors[i%4]))
            # Line chart: last 7 days
            line_series = self.line_chart_view.chart().series()[0]
            line_series.clear()
            today = QDate.currentDate()
            for i in range(6, -1, -1):
                d = today.addDays(-i)
                cur.execute(f"SELECT COUNT(*) FROM documents WHERE DATE(added_date)='{d.toString('yyyy-MM-dd')}' AND {date_filter}")
                cnt = cur.fetchone()[0]
                line_series.append(6 - i, cnt)
            # Bar chart: incoming/outgoing per last 3 months
            bar_series = self.bar_chart_view.chart().series()
            if len(bar_series)>=2:
                inc_set = bar_series[0]; out_set = bar_series[1]
                inc_set.clear(); out_set.clear()
                inc_data = []; out_data = []
                months = []
                for i in range(2, -1, -1):
                    m = today.addMonths(-i)
                    months.append(m.toString("MMM yyyy"))
                    start = QDate(m.year(), m.month(), 1)
                    end = start.addMonths(1).addDays(-1)
                    cur.execute(f"SELECT COUNT(*) FROM documents WHERE incoming_outgoing='وارد' AND doc_date BETWEEN '{start.toString('yyyy-MM-dd')}' AND '{end.toString('yyyy-MM-dd')}' AND {date_filter}")
                    inc_data.append(cur.fetchone()[0])
                    cur.execute(f"SELECT COUNT(*) FROM documents WHERE incoming_outgoing='صادر' AND doc_date BETWEEN '{start.toString('yyyy-MM-dd')}' AND '{end.toString('yyyy-MM-dd')}' AND {date_filter}")
                    out_data.append(cur.fetchone()[0])
                inc_set.append(inc_data); out_set.append(out_data)
                # update axis labels
                axis_x = self.bar_chart_view.chart().axes(Qt.AlignBottom)[0]
                axis_x.clear()
                axis_x.append(months)
            # Category bar chart (top 5 categories)
            cat_series = self.cat_chart_view.chart().series()[0]
            cat_series.clear()
            cur.execute(f"""
                SELECT c.name, COUNT(d.id) FROM documents d
                LEFT JOIN categories c ON d.category_id = c.id
                WHERE {date_filter}
                GROUP BY d.category_id
                ORDER BY COUNT(d.id) DESC LIMIT 5
            """)
            cats = cur.fetchall()
            if cats:
                names = [c[0] or "بدون تصنيف" for c in cats]
                counts = [c[1] for c in cats]
                bar_set = QBarSet("الوثائق")
                bar_set.append(counts)
                cat_series.append(bar_set)
                axis_x = self.cat_chart_view.chart().axes(Qt.AlignBottom)[0]
                axis_x.clear()
                axis_x.append(names)
        print("Charts updated")

    def refresh_all(self):
        self.load_stats()
        self.load_charts()

    def export_dashboard_image(self):
        # تصدير منطقة التمرير بأكملها
        area = self.findChild(QScrollArea)
        if not area:
            area = self
        pixmap = area.grab()
        filename = QFileDialog.getSaveFileName(self, "حفظ الصورة", "dashboard.png", "PNG (*.png)")[0]
        if filename:
            pixmap.save(filename)
            QMessageBox.information(self, "تم", f"تم حفظ لوحة التحكم كصورة في {filename}")