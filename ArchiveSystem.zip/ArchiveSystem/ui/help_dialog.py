# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt

class HelpDialog(QDialog):
    def __init__(self, context: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("مساعدة - نظام الأرشفة الإلكتروني")
        self.setMinimumSize(550, 500)
        self.setLayoutDirection(Qt.RightToLeft)
        self.init_ui(context)
    
    def init_ui(self, context: str):
        layout = QVBoxLayout(self)
        
        title = QLabel("📖 دليل المساعدة")
        title.setStyleSheet("font-size: 20px; font-weight: bold; color: #1e3c72;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        help_text = QTextEdit()
        help_text.setReadOnly(True)
        help_text.setStyleSheet("""
            QTextEdit {
                background-color: #f8fafc;
                border: 1px solid #cbd5e1;
                border-radius: 12px;
                padding: 15px;
                font-size: 14px;
            }
        """)
        
        help_text.setHtml(self.get_help_content(context))
        layout.addWidget(help_text)
        
        close_btn = QPushButton("إغلاق")
        close_btn.clicked.connect(self.accept)
        close_btn.setStyleSheet("""
            QPushButton {
                background-color: #1e3c72;
                color: white;
                border-radius: 8px;
                padding: 8px 20px;
                font-weight: bold;
            }
            QPushButton:hover { background-color: #2c5a92; }
        """)
        layout.addWidget(close_btn, alignment=Qt.AlignCenter)
    
    def get_help_content(self, context: str) -> str:
        if context == "documents":
            return self.get_documents_help()
        elif context == "search":
            return self.get_search_help()
        elif context == "users":
            return self.get_users_help()
        elif context == "parties":
            return self.get_parties_help()
        elif context == "categories":
            return self.get_categories_help()
        elif context == "contacts":
            return self.get_contacts_help()
        elif context == "correspondence":
            return self.get_correspondence_help()
        elif context == "tags":
            return self.get_tags_help()
        elif context == "archive":
            return self.get_archive_help()
        elif context == "reports":
            return self.get_reports_help()
        elif context == "settings":
            return self.get_settings_help()
        elif context == "backup":
            return self.get_backup_help()
        else:
            return self.get_general_help()
    
    def get_general_help(self):
        return """
        <h2>🏢 نظام الأرشفة الإلكتروني</h2>
        <p>هذا النظام يساعدك على إدارة الوثائق والمعاملات بشكل منظم وآمن.</p>
        <hr>
        <h3>📌 الأقسام الرئيسية:</h3>
        <ul>
            <li><strong>📊 لوحة التحكم:</strong> إحصائيات ورسوم بيانية عن الوثائق.</li>
            <li><strong>📄 الوثائق:</strong> إضافة، تعديل، أرشفة، وحذف الوثائق.</li>
            <li><strong>🔍 بحث متقدم:</strong> البحث في الوثائق بمعايير متعددة.</li>
            <li><strong>👥 المستخدمين:</strong> إدارة حسابات المستخدمين (للمدير فقط).</li>
            <li><strong>📎 الجهات الخارجية:</strong> إدارة جهات المراسلة.</li>
            <li><strong>🏷️ التصنيفات:</strong> إنشاء هيكل شجري لتصنيف الوثائق.</li>
            <li><strong>📞 جهات الاتصال:</strong> إدارة المرسلين والمستلمين الداخليين.</li>
            <li><strong>🔄 المراسلات:</strong> تتبع المراسلات المرتبطة بالوثائق.</li>
            <li><strong>🏷️ الكلمات المفتاحية:</strong> إدارة الوسوم لتصنيف إضافي.</li>
            <li><strong>📦 الأرشيف:</strong> عرض واسترجاع الوثائق المؤرشفة.</li>
            <li><strong>📑 التقارير:</strong> إنشاء وتصدير تقارير إحصائية.</li>
            <li><strong>⚙️ الإعدادات:</strong> ضبط مظهر البرنامج ومسار الأرشيف.</li>
            <li><strong>💾 النسخ الاحتياطي:</strong> إنشاء واستعادة نسخ احتياطية.</li>
        </ul>
        <h3>⌨️ اختصارات لوحة المفاتيح:</h3>
        <ul>
            <li><strong>Ctrl+N:</strong> إضافة وثيقة جديدة</li>
            <li><strong>Ctrl+F:</strong> الانتقال إلى البحث</li>
            <li><strong>F5:</strong> تحديث الجدول الحالي</li>
        </ul>
        """
    
    def get_documents_help(self):
        return """
        <h2>📄 إدارة الوثائق</h2>
        <p>هذه الواجهة تسمح لك بإدارة جميع الوثائق في النظام.</p>
        <h3>🧰 شريط الأدوات:</h3>
        <ul>
            <li><strong>➕ إضافة وثيقة:</strong> فتح نافذة لإدخال وثيقة جديدة.</li>
            <li><strong>✏️ تعديل:</strong> تعديل الوثيقة المحددة.</li>
            <li><strong>📦 أرشفة:</strong> نقل الوثيقة إلى الأرشيف (يمكن استرجاعها لاحقاً).</li>
            <li><strong>🗑️ حذف نهائي:</strong> حذف الوثيقة وجميع مرفقاتها بشكل دائم.</li>
            <li><strong>🔄 استرجاع:</strong> إعادة وثيقة من الأرشيف إلى الوثائق النشطة.</li>
            <li><strong>📷 مسح ضوئي:</strong> تشغيل الماسح الضوئي وإضافة الصورة كمرفق.</li>
            <li><strong>🔄 تحديث:</strong> إعادة تحميل جدول الوثائق.</li>
        </ul>
        <h3>📋 حقول إضافة/تعديل وثيقة:</h3>
        <ul>
            <li><strong>🔢 رقم المعاملة (إجباري):</strong> رقم فريد تحدده أنت، لا يمكن تكراره لنفس السنة ونفس النوع.</li>
            <li><strong>📝 العنوان (إجباري):</strong> عنوان الوثيقة.</li>
            <li><strong>📅 التاريخ:</strong> تاريخ الوثيقة (يُستخدم لتحديد السنة).</li>
            <li><strong>👤 المرسل/المستلم:</strong> اختر من قائمة جهات الاتصال الداخلية.</li>
            <li><strong>📄 الوصف:</strong> نص حر لشرح محتوى الوثيقة.</li>
            <li><strong>🏷️ النوع/الحالة/الأولوية:</strong> تصنيفات إضافية للوثيقة.</li>
            <li><strong>📂 التصنيف:</strong> من شجرة التصنيفات.</li>
            <li><strong>🏢 الجهة الخارجية:</strong> الجهة المرتبطة بالوثيقة (شركة، وزارة، إلخ).</li>
            <li><strong>⬅️➡️ وارد/صادر:</strong> تحديد اتجاه المعاملة.</li>
            <li><strong>🔖 الكلمات المفتاحية:</strong> وسوم مفصولة بفواصل لتسهيل البحث.</li>
            <li><strong>📎 المرفقات:</strong> إضافة ملفات (PDF، صور، Word، إلخ).</li>
        </ul>
        <p><strong>💡 نصيحة:</strong> يمكنك النقر المزدوج على أي وثيقة في الجدول لعرض تفاصيلها.</p>
        """
    
    def get_search_help(self):
        return """
        <h2>🔍 البحث المتقدم</h2>
        <p>هذه الواجهة تسمح لك بالبحث في الوثائق بمعايير متعددة.</p>
        <h3>⚡ البحث السريع:</h3>
        <ul><li>اكتب كلمة مفتاحية في حقل "بحث سريع" - يبحث في العنوان، رقم المعاملة، رقم الوثيقة، الوصف، الوسوم.</li></ul>
        <h3>🎯 البحث المتقدم:</h3>
        <ul>
            <li><strong>رقم المعاملة:</strong> بحث دقيق برقم المعاملة.</li>
            <li><strong>رقم الوثيقة:</strong> بحث جزئي برقم الوثيقة.</li>
            <li><strong>العنوان:</strong> بحث جزئي بالعنوان.</li>
            <li><strong>نطاق تاريخي:</strong> من تاريخ إلى تاريخ.</li>
            <li><strong>النوع، الحالة، الأولوية، التصنيف، نوع المعاملة:</strong> قوائم منسدلة لتصفية النتائج.</li>
        </ul>
        <p><strong>💡 نصيحة:</strong> انقر نقراً مزدوجاً على أي نتيجة لفتح الوثيقة وعرض تفاصيلها.</p>
        """
    
    def get_users_help(self):
        return """
        <h2>👥 إدارة المستخدمين</h2>
        <p>هذه الواجهة متاحة فقط للمدير.</p>
        <ul>
            <li><strong>➕ إضافة مستخدم:</strong> إنشاء حساب جديد (اسم مستخدم، كلمة مرور، اسم كامل، بريد، دور).</li>
            <li><strong>✏️ تعديل:</strong> تغيير بيانات المستخدم (الاسم، البريد، الدور، الحالة النشطة).</li>
            <li><strong>🗑️ حذف:</strong> حذف مستخدم (لا يمكن حذف المدير).</li>
            <li><strong>🔑 تغيير كلمة المرور:</strong> تعيين كلمة مرور جديدة للمستخدم.</li>
        </ul>
        <h3>👑 الأدوار:</h3>
        <ul><li><strong>admin:</strong> صلاحيات كاملة.</li><li><strong>user:</strong> صلاحيات محدودة (لا يرى قسم المستخدمين).</li></ul>
        """
    
    def get_parties_help(self):
        return """
        <h2>📎 الجهات الخارجية</h2>
        <p>إدارة جهات المراسلة الخارجية (شركات، مؤسسات، أفراد). تُستخدم في قائمة "الجهة الخارجية" عند إضافة وثيقة.</p>
        <ul><li><strong>➕ إضافة جهة:</strong> كود، اسم، نوع، جهة اتصال، هاتف، بريد.</li><li><strong>✏️ تعديل / 🗑️ حذف.</strong></li></ul>
        """
    
    def get_categories_help(self):
        return """
        <h2>🏷️ التصنيفات (الشجرية)</h2>
        <p>إنشاء هيكل هرمي لتصنيف الوثائق.</p>
        <ul><li><strong>➕ إضافة تصنيف:</strong> اسم، كود، وصف، أب اختياري.</li><li><strong>✏️ تعديل / 🗑️ حذف.</strong></li></ul>
        <pre>📁 عقود\n   📁 عقود البيع\n   📁 عقود الإيجار\n📁 مراسلات\n   📁 واردة\n   📁 صادرة</pre>
        """
    
    def get_contacts_help(self):
        return """
        <h2>📞 جهات الاتصال (مرسل/مستلم)</h2>
        <p>إدارة جهات الاتصال الداخلية (أقسام، إدارات، أشخاص). تظهر في حقلي "المرسل" و "المستلم" عند إضافة وثيقة.</p>
        <ul><li><strong>النوع:</strong> مرسل (يظهر في قائمة المرسلين فقط)، مستلم، كلاهما.</li></ul>
        """
    
    def get_correspondence_help(self):
        return """
        <h2>🔄 المراسلات</h2>
        <p>تتبع المراسلات المرتبطة بالوثائق.</p>
        <ul><li>اختر وثيقة → ستظهر المراسلات المرتبطة بها.</li><li>➕ إضافة مراسلة: من، إلى، الموضوع، المحتوى، التواريخ، الحالة، رقم تتبع.</li></ul>
        """
    
    def get_tags_help(self):
        return """
        <h2>🏷️ الكلمات المفتاحية (Tags)</h2>
        <p>تعرض جميع الكلمات المفتاحية المستخدمة في النظام وعدد مرات استخدامها. يمكنك إضافة وسوم جديدة هنا.</p>
        """
    
    def get_archive_help(self):
        return """
        <h2>📦 الأرشيف</h2>
        <p>عرض الوثائق المؤرشفة فقط.</p>
        <ul><li><strong>🔄 استرجاع:</strong> إعادة الوثيقة إلى الوثائق النشطة.</li><li><strong>🔄 تحديث.</strong></li></ul>
        """
    
    def get_reports_help(self):
        return """
        <h2>📑 التقارير والإحصائيات</h2>
        <p>إحصائيات عن النظام: إجمالي الوثائق، الوارد، الصادر، مساحة التخزين.</p>
        <p><strong>📤 تصدير التقرير:</strong> اختر نوع التقرير، الصيغة (CSV/PDF)، ثم مسار الحفظ.</p>
        """
    
    def get_settings_help(self):
        return """
        <h2>⚙️ الإعدادات</h2>
        <ul><li><strong>🎨 المظهر:</strong> فاتح / داكن (يُطبق بعد إعادة التشغيل).</li>
        <li><strong>🗂️ الأرشيف:</strong> تحديد مجلد لحفظ المرفقات. يمكن نقل الملفات القديمة تلقائياً أو إصلاح المسارات يدوياً.</li>
        <li><strong>💾 النسخ الاحتياطي:</strong> تفعيل النسخ التلقائي كل X ساعة.</li></ul>
        """
    
    def get_backup_help(self):
        return """
        <h2>💾 النسخ الاحتياطي</h2>
        <ul><li><strong>➕ إنشاء نسخة يدوية:</strong> ضغط قاعدة البيانات والمرفقات في ملف ZIP.</li>
        <li><strong>🔄 استعادة نسخة:</strong> اختيار ملف ZIP واستعادة النظام بالكامل (يتطلب إعادة التشغيل).</li>
        <li><strong>🗑️ حذف نسخة.</strong></li></ul>
        """