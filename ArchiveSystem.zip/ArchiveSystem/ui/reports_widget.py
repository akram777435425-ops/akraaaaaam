
# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt, QDate
from services.report_service import ReportService
from database.db_manager import DatabaseManager
import os
from config.settings import Settings

class ReportsWidget(QWidget):
    def __init__(self, db_manager: DatabaseManager):
        super().__init__()
        self.db_manager = db_manager
        self.report_service = ReportService(db_manager)
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(20)
        
        title = QLabel("التقارير والإحصائيات")
        title.setStyleSheet("font-size: 20px; font-weight: bold;")
        layout.addWidget(title)
        
        # إحصائيات سريعة
        stats = self.report_service.generate_statistics()
        stats_grid = QGridLayout()
        stats_grid.addWidget(QLabel("إجمالي الوثائق:"), 0,0)
        stats_grid.addWidget(QLabel(str(stats['total_documents'])), 0,1)
        stats_grid.addWidget(QLabel("الوثائق المؤرشفة:"), 1,0)
        stats_grid.addWidget(QLabel(str(stats['archived_documents'])), 1,1)
        stats_grid.addWidget(QLabel("الوارد:"), 2,0)
        stats_grid.addWidget(QLabel(str(stats['incoming_count'])), 2,1)
        stats_grid.addWidget(QLabel("الصادر:"), 3,0)
        stats_grid.addWidget(QLabel(str(stats['outgoing_count'])), 3,1)
        stats_grid.addWidget(QLabel("مساحة التخزين:"), 4,0)
        stats_grid.addWidget(QLabel(f"{stats['storage_used_mb']} MB"), 4,1)
        layout.addLayout(stats_grid)
        
        # خيارات التصدير
        export_group = QGroupBox("تصدير التقرير")
        export_layout = QHBoxLayout()
        self.report_type = QComboBox()
        self.report_type.addItems(["تقارير الوثائق", "إحصائيات المعاملات", "تقرير الأداء"])
        self.export_format = QComboBox()
        self.export_format.addItems(["CSV", "PDF"])
        export_btn = QPushButton("تصدير")
        export_btn.clicked.connect(self.export_report)
        export_layout.addWidget(QLabel("نوع التقرير:"))
        export_layout.addWidget(self.report_type)
        export_layout.addWidget(QLabel("الصيغة:"))
        export_layout.addWidget(self.export_format)
        export_layout.addWidget(export_btn)
        export_group.setLayout(export_layout)
        layout.addWidget(export_group)
    
    def export_report(self):
        report_type = self.report_type.currentText()
        fmt = self.export_format.currentText()
        with self.db_manager.get_connection() as conn:
            cursor = conn.cursor()
            if report_type == "تقارير الوثائق":
                cursor.execute("SELECT * FROM documents LIMIT 1000")
                rows = cursor.fetchall()
                data = [dict(row) for row in rows]
            else:
                data = [self.report_service.generate_statistics()]
        
        file_filter = "CSV files (*.csv)" if fmt == "CSV" else "PDF files (*.pdf)"
        default_name = f"report_{report_type}_{QDate.currentDate().toString('yyyyMMdd')}.{fmt.lower()}"
        path, _ = QFileDialog.getSaveFileName(self, "حفظ التقرير", default_name, file_filter)
        if not path:
            return
        if fmt == "CSV":
            # استخدام تصدير CSV
            import csv
            if data:
                with open(path, 'w', newline='', encoding='utf-8-sig') as f:
                    writer = csv.DictWriter(f, fieldnames=data[0].keys())
                    writer.writeheader()
                    writer.writerows(data)
                success = True
            else:
                success = False
        else:
            success = self.report_service.export_to_pdf(data, path)
        
        if success:
            QMessageBox.information(self, "تم", f"تم حفظ التقرير في {path}")
        else:
            QMessageBox.critical(self, "خطأ", "فشل في إنشاء التقرير")
