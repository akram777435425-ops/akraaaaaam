
# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from database.db_manager import DatabaseManager

class PartiesWidget(QWidget):
    def __init__(self, db_manager: DatabaseManager):
        super().__init__()
        self.db_manager = db_manager
        self.init_ui()
        self.load_parties()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        toolbar = QHBoxLayout()
        self.add_btn = QPushButton("إضافة جهة")
        self.edit_btn = QPushButton("تعديل")
        self.delete_btn = QPushButton("حذف")
        toolbar.addWidget(self.add_btn)
        toolbar.addWidget(self.edit_btn)
        toolbar.addWidget(self.delete_btn)
        layout.addLayout(toolbar)
        
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["الكود", "الاسم", "النوع", "جهة اتصال", "الهاتف", "البريد"])
        layout.addWidget(self.table)
        
        self.add_btn.clicked.connect(self.add_party)
        self.edit_btn.clicked.connect(self.edit_party)
        self.delete_btn.clicked.connect(self.delete_party)
    
    def load_parties(self):
        with self.db_manager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, code, name, type, contact_person, phone, email FROM correspondents")
            rows = cursor.fetchall()
            self.table.setRowCount(len(rows))
            for i, row in enumerate(rows):
                self.table.setItem(i, 0, QTableWidgetItem(row['code'] or ''))
                self.table.setItem(i, 1, QTableWidgetItem(row['name']))
                self.table.setItem(i, 2, QTableWidgetItem(row['type'] or ''))
                self.table.setItem(i, 3, QTableWidgetItem(row['contact_person'] or ''))
                self.table.setItem(i, 4, QTableWidgetItem(row['phone'] or ''))
                self.table.setItem(i, 5, QTableWidgetItem(row['email'] or ''))
                self.table.item(i, 1).setData(Qt.UserRole, row['id'])
    
    def add_party(self):
        dialog = PartyDialog(self.db_manager)
        if dialog.exec_():
            self.load_parties()
    
    def edit_party(self):
        row = self.table.currentRow()
        if row < 0:
            return
        party_id = self.table.item(row, 1).data(Qt.UserRole)
        dialog = PartyDialog(self.db_manager, party_id)
        if dialog.exec_():
            self.load_parties()
    
    def delete_party(self):
        row = self.table.currentRow()
        if row < 0:
            return
        party_id = self.table.item(row, 1).data(Qt.UserRole)
        confirm = QMessageBox.question(self, "تأكيد", "حذف الجهة؟", QMessageBox.Yes|QMessageBox.No)
        if confirm == QMessageBox.Yes:
            with self.db_manager.get_connection() as conn:
                conn.execute("DELETE FROM correspondents WHERE id=?", (party_id,))
            self.load_parties()

class PartyDialog(QDialog):
    def __init__(self, db_manager, party_id=None):
        super().__init__()
        self.db_manager = db_manager
        self.party_id = party_id
        self.setWindowTitle("جهة")
        self.setLayoutDirection(Qt.RightToLeft)
        layout = QFormLayout(self)
        self.code_edit = QLineEdit()
        self.name_edit = QLineEdit()
        self.type_edit = QLineEdit()
        self.contact_edit = QLineEdit()
        self.phone_edit = QLineEdit()
        self.email_edit = QLineEdit()
        self.address_edit = QTextEdit()
        layout.addRow("الكود:", self.code_edit)
        layout.addRow("الاسم *:", self.name_edit)
        layout.addRow("النوع:", self.type_edit)
        layout.addRow("جهة اتصال:", self.contact_edit)
        layout.addRow("الهاتف:", self.phone_edit)
        layout.addRow("البريد:", self.email_edit)
        layout.addRow("العنوان:", self.address_edit)
        btns = QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel)
        btns.accepted.connect(self.save)
        btns.rejected.connect(self.reject)
        layout.addRow(btns)
        if party_id:
            self.load_data()
    
    def load_data(self):
        with self.db_manager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM correspondents WHERE id=?", (self.party_id,))
            row = cursor.fetchone()
            if row:
                self.code_edit.setText(row['code'] or '')
                self.name_edit.setText(row['name'])
                self.type_edit.setText(row['type'] or '')
                self.contact_edit.setText(row['contact_person'] or '')
                self.phone_edit.setText(row['phone'] or '')
                self.email_edit.setText(row['email'] or '')
                self.address_edit.setPlainText(row['address'] or '')
    
    def save(self):
        if not self.name_edit.text().strip():
            QMessageBox.warning(self, "تنبيه", "الاسم مطلوب")
            return
        with self.db_manager.get_connection() as conn:
            cursor = conn.cursor()
            if self.party_id:
                cursor.execute("""
                    UPDATE correspondents SET code=?, name=?, type=?, contact_person=?, phone=?, email=?, address=?
                    WHERE id=?
                """, (self.code_edit.text(), self.name_edit.text(), self.type_edit.text(),
                      self.contact_edit.text(), self.phone_edit.text(), self.email_edit.text(),
                      self.address_edit.toPlainText(), self.party_id))
            else:
                cursor.execute("""
                    INSERT INTO correspondents (code, name, type, contact_person, phone, email, address)
                    VALUES (?,?,?,?,?,?,?)
                """, (self.code_edit.text(), self.name_edit.text(), self.type_edit.text(),
                      self.contact_edit.text(), self.phone_edit.text(), self.email_edit.text(),
                      self.address_edit.toPlainText()))
        self.accept()
