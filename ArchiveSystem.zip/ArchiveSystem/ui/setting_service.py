# -*- coding: utf-8 -*-
from pathlib import Path
from database.db_manager import DatabaseManager

class SettingService:
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager

    def get(self, key: str, default=None):
        with self.db.get_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT value FROM system_settings WHERE key = ?", (key,))
            row = cur.fetchone()
            if row:
                return row['value']
            return default

    def set(self, key: str, value: str):
        with self.db.get_connection() as conn:
            cur = conn.cursor()
            cur.execute("INSERT OR REPLACE INTO system_settings (key, value) VALUES (?, ?)", (key, value))

    def get_archive_path(self) -> Path:
        """إرجاع مسار الأرشيف المخزن أو الافتراضي"""
        saved = self.get("archive_root")
        if saved:
            return Path(saved)
        return Settings.DEFAULT_ARCHIVE_ROOT

    def set_archive_path(self, path: str):
        self.set("archive_root", path)
        # تحديث الإعدادات الثابتة ديناميكياً (لتستخدمه باقي أجزاء البرنامج فوراً)
        Settings.ARCHIVE_ROOT = Path(path)