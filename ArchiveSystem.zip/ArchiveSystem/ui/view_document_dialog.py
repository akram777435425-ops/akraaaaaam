# -*- coding: utf-8 -*-
import os
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt

class ViewDocumentDialog(QDialog):
    def __init__(self, db_manager, doc_id, user):
        super().__init__()
        self.db_manager = db_manager
        self.doc_id = doc_id
        self.user = user
        self.setWindowTitle("عرض الوثيقة")
        self.setMinimumSize(800, 600)
        self.setLayoutDirection(Qt.RightToLeft)
        self.init_ui()
        self.load_document()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # مجموعة معلومات الوثيقة
        info_group = QGroupBox("معلومات الوثيقة")
        info_layout = QFormLayout(info_group)
        
        self.title_label = QLabel()
        self.doc_number_label = QLabel()
        self.transaction_label = QLabel()
        self.date_label = QLabel()
        self.sender_label = QLabel()
        self.recipient_label = QLabel()
        self.status_label = QLabel()
        self.type_label = QLabel()
        self.priority_label = QLabel()
        self.desc_label = QLabel()
        self.desc_label.setWordWrap(True)
        
        info_layout.addRow("العنوان:", self.title_label)
        info_layout.addRow("رقم الوثيقة:", self.doc_number_label)
        info_layout.addRow("رقم المعاملة:", self.transaction_label)
        info_layout.addRow("التاريخ:", self.date_label)
        info_layout.addRow("المرسل:", self.sender_label)
        info_layout.addRow("المستلم:", self.recipient_label)
        info_layout.addRow("الحالة:", self.status_label)
        info_layout.addRow("النوع:", self.type_label)
        info_layout.addRow("الأولوية:", self.priority_label)
        info_layout.addRow("الوصف:", self.desc_label)
        
        layout.addWidget(info_group)
        
        # مجموعة المرفقات
        attach_group = QGroupBox("المرفقات")
        attach_layout = QVBoxLayout(attach_group)
        self.attachments_list = QListWidget()
        self.attachments_list.itemDoubleClicked.connect(self.open_attachment)
        attach_layout.addWidget(self.attachments_list)
        layout.addWidget(attach_group)
        
        # أزرار الإغلاق
        btn_layout = QHBoxLayout()
        close_btn = QPushButton("إغلاق")
        close_btn.clicked.connect(self.accept)
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)
    
    def load_document(self):
        from services.document_service import DocumentService
        ds = DocumentService(self.db_manager)
        doc = ds.get_document(self.doc_id)
        if doc:
            self.title_label.setText(doc.get('title', ''))
            self.doc_number_label.setText(doc.get('doc_number', ''))
            self.transaction_label.setText(doc.get('transaction_number', ''))
            self.date_label.setText(doc.get('doc_date', ''))
            self.sender_label.setText(doc.get('sender', ''))  # أو اسم المرسل من جدول contacts إذا كنت تستخدم sender_id
            self.recipient_label.setText(doc.get('recipient', ''))
            self.status_label.setText(doc.get('doc_status', ''))
            self.type_label.setText(doc.get('doc_type', ''))
            self.priority_label.setText(doc.get('priority', ''))
            self.desc_label.setText(doc.get('description', ''))
            
            attachments = ds.get_attachments(self.doc_id)
            for att in attachments:
                item = QListWidgetItem(att['filename'])
                item.setData(Qt.UserRole, att['filepath'])
                self.attachments_list.addItem(item)
        else:
            QMessageBox.warning(self, "خطأ", "لم يتم العثور على الوثيقة")
    
    def open_attachment(self, item):
        filepath = item.data(Qt.UserRole)
        if filepath and os.path.exists(filepath):
            if os.name == 'nt':
                os.startfile(filepath)
            else:
                QMessageBox.information(self, "تنبيه", "فتح الملفات غير مدعوم على هذا النظام")
        else:
            QMessageBox.warning(self, "خطأ", f"الملف غير موجود:\n{filepath}")