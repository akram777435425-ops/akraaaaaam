# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt
from services.contact_service import ContactService

class ContactsManagementWidget(QWidget):
    def __init__(self, db_manager):
        super().__init__()
        self.db_manager = db_manager
        self.contact_service = ContactService(db_manager)
        self.init_ui()
        self.refresh_table()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        toolbar = QHBoxLayout()
        self.add_btn = QPushButton("إضافة جهة اتصال")
        self.edit_btn = QPushButton("تعديل")
        self.delete_btn = QPushButton("حذف")
        toolbar.addWidget(self.add_btn)
        toolbar.addWidget(self.edit_btn)
        toolbar.addWidget(self.delete_btn)
        layout.addLayout(toolbar)
        
        self.table = QTableWidget()
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels(["الاسم", "النوع", "الكود", "الهاتف", "البريد", "نشط", "ملاحظات"])
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.table)
        
        self.add_btn.clicked.connect(self.add_contact)
        self.edit_btn.clicked.connect(self.edit_contact)
        self.delete_btn.clicked.connect(self.delete_contact)
    
    def refresh_table(self):
        contacts = self.contact_service.get_all_contacts()
        self.table.setRowCount(len(contacts))
        for i, c in enumerate(contacts):
            self.table.setItem(i, 0, QTableWidgetItem(c['name']))
            type_text = ""
            if c['contact_type'] == 'sender':
                type_text = "مرسل"
            elif c['contact_type'] == 'recipient':
                type_text = "مستلم"
            elif c['contact_type'] == 'both':
                type_text = "مرسل ومستلم"
            self.table.setItem(i, 1, QTableWidgetItem(type_text))
            self.table.setItem(i, 2, QTableWidgetItem(c.get('code', '')))
            self.table.setItem(i, 3, QTableWidgetItem(c.get('phone', '')))
            self.table.setItem(i, 4, QTableWidgetItem(c.get('email', '')))
            self.table.setItem(i, 5, QTableWidgetItem("نعم" if c['is_active'] else "لا"))
            self.table.item(i, 0).setData(Qt.UserRole, c['id'])
    
    def add_contact(self):
        dialog = ContactDialog(self.db_manager)
        if dialog.exec_():
            self.refresh_table()
    
    def edit_contact(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "تنبيه", "اختر جهة اتصال أولاً")
            return
        contact_id = self.table.item(row, 0).data(Qt.UserRole)
        dialog = ContactDialog(self.db_manager, contact_id)
        if dialog.exec_():
            self.refresh_table()
    
    def delete_contact(self):
        row = self.table.currentRow()
        if row < 0:
            return
        contact_id = self.table.item(row, 0).data(Qt.UserRole)
        name = self.table.item(row, 0).text()
        confirm = QMessageBox.question(self, "تأكيد", f"هل تريد حذف '{name}'؟", QMessageBox.Yes|QMessageBox.No)
        if confirm == QMessageBox.Yes:
            try:
                self.contact_service.delete_contact(contact_id)
                self.refresh_table()
            except ValueError as e:
                QMessageBox.warning(self, "تنبيه", str(e))

class ContactDialog(QDialog):
    def __init__(self, db_manager, contact_id=None):
        super().__init__()
        self.db_manager = db_manager
        self.contact_id = contact_id
        self.contact_service = ContactService(db_manager)
        self.setWindowTitle("جهة اتصال (مرسل/مستلم)")
        self.setMinimumWidth(450)
        self.setLayoutDirection(Qt.RightToLeft)
        self.init_ui()
        if contact_id:
            self.load_data()
    
    def init_ui(self):
        layout = QFormLayout(self)
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("الاسم (مثال: مدير المالية)")
        self.type_combo = QComboBox()
        self.type_combo.addItems(["مرسل", "مستلم", "مرسل ومستلم"])
        self.type_combo.setCurrentIndex(0)
        self.code_edit = QLineEdit()
        self.code_edit.setPlaceholderText("كود اختياري")
        self.phone_edit = QLineEdit()
        self.email_edit = QLineEdit()
        self.address_edit = QTextEdit()
        self.address_edit.setMaximumHeight(80)
        self.notes_edit = QTextEdit()
        self.notes_edit.setMaximumHeight(80)
        self.active_check = QCheckBox("نشط")
        self.active_check.setChecked(True)
        
        layout.addRow("الاسم *:", self.name_edit)
        layout.addRow("النوع:", self.type_combo)
        layout.addRow("الكود:", self.code_edit)
        layout.addRow("الهاتف:", self.phone_edit)
        layout.addRow("البريد الإلكتروني:", self.email_edit)
        layout.addRow("العنوان:", self.address_edit)
        layout.addRow("ملاحظات:", self.notes_edit)
        layout.addRow(self.active_check)
        
        btns = QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel)
        btns.accepted.connect(self.save)
        btns.rejected.connect(self.reject)
        layout.addRow(btns)
    
    def load_data(self):
        contacts = self.contact_service.get_all_contacts()
        for c in contacts:
            if c['id'] == self.contact_id:
                self.name_edit.setText(c['name'])
                t = c['contact_type']
                if t == 'sender':
                    self.type_combo.setCurrentIndex(0)
                elif t == 'recipient':
                    self.type_combo.setCurrentIndex(1)
                else:
                    self.type_combo.setCurrentIndex(2)
                self.code_edit.setText(c.get('code', ''))
                self.phone_edit.setText(c.get('phone', ''))
                self.email_edit.setText(c.get('email', ''))
                self.active_check.setChecked(c['is_active'] == 1)
                break
    
    def save(self):
        name = self.name_edit.text().strip()
        if not name:
            QMessageBox.warning(self, "تنبيه", "الاسم مطلوب")
            return
        type_map = {0: 'sender', 1: 'recipient', 2: 'both'}
        contact_type = type_map[self.type_combo.currentIndex()]
        code = self.code_edit.text().strip()
        phone = self.phone_edit.text().strip()
        email = self.email_edit.text().strip()
        address = self.address_edit.toPlainText().strip()
        notes = self.notes_edit.toPlainText().strip()
        is_active = self.active_check.isChecked()
        
        if self.contact_id:
            self.contact_service.update_contact(self.contact_id, name, contact_type, code, phone, email, address, notes, is_active)
        else:
            self.contact_service.add_contact(name, contact_type, code, phone, email, address, notes)
        self.accept()