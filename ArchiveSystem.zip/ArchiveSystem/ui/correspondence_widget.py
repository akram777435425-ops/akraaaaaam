
# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt, QDate
from services.correspondence_service import CorrespondenceService

class CorrespondenceWidget(QWidget):
    def __init__(self, db_manager):
        super().__init__()
        self.db_manager = db_manager
        self.service = CorrespondenceService(db_manager)
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        self.doc_combo = QComboBox()
        self.load_documents()
        layout.addWidget(QLabel("اختر الوثيقة:"))
        layout.addWidget(self.doc_combo)
        
        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["من", "إلى", "الموضوع", "التاريخ", "الحالة"])
        layout.addWidget(self.table)
        
        add_btn = QPushButton("إضافة مراسلة")
        add_btn.clicked.connect(self.add_correspondence)
        layout.addWidget(add_btn)
        
        self.doc_combo.currentIndexChanged.connect(self.load_correspondences)
    
    def load_documents(self):
        with self.db_manager.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, doc_number, title FROM documents")
            for row in cursor.fetchall():
                self.doc_combo.addItem(f"{row['doc_number']} - {row['title']}", row['id'])
    
    def load_correspondences(self):
        doc_id = self.doc_combo.currentData()
        if not doc_id:
            return
        corrs = self.service.get_correspondence_by_document(doc_id)
        self.table.setRowCount(len(corrs))
        for i, c in enumerate(corrs):
            self.table.setItem(i, 0, QTableWidgetItem(c.get('from_entity', '')))
            self.table.setItem(i, 1, QTableWidgetItem(c.get('to_entity', '')))
            self.table.setItem(i, 2, QTableWidgetItem(c.get('subject', '')))
            self.table.setItem(i, 3, QTableWidgetItem(c.get('sent_date', '')))
            self.table.setItem(i, 4, QTableWidgetItem(c.get('status', '')))
    
    def add_correspondence(self):
        doc_id = self.doc_combo.currentData()
        if not doc_id:
            QMessageBox.warning(self, "تنبيه", "اختر وثيقة أولاً")
            return
        dialog = CorrespondenceDialog(self.db_manager, doc_id)
        if dialog.exec_():
            self.load_correspondences()

class CorrespondenceDialog(QDialog):
    def __init__(self, db_manager, doc_id):
        super().__init__()
        self.db_manager = db_manager
        self.doc_id = doc_id
        self.setWindowTitle("إضافة مراسلة")
        self.setLayoutDirection(Qt.RightToLeft)
        layout = QFormLayout(self)
        self.from_edit = QLineEdit()
        self.to_edit = QLineEdit()
        self.subject_edit = QLineEdit()
        self.content_edit = QTextEdit()
        self.sent_date = QDateEdit()
        self.sent_date.setDate(QDate.currentDate())
        self.received_date = QDateEdit()
        self.received_date.setDate(QDate.currentDate())
        self.status_combo = QComboBox()
        self.status_combo.addItems(["مرسلة", "مستلمة", "قيد المعالجة", "مغلقة"])
        self.tracking_edit = QLineEdit()
        
        layout.addRow("من:", self.from_edit)
        layout.addRow("إلى:", self.to_edit)
        layout.addRow("الموضوع:", self.subject_edit)
        layout.addRow("المحتوى:", self.content_edit)
        layout.addRow("تاريخ الإرسال:", self.sent_date)
        layout.addRow("تاريخ الاستلام:", self.received_date)
        layout.addRow("الحالة:", self.status_combo)
        layout.addRow("رقم التتبع:", self.tracking_edit)
        
        btns = QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel)
        btns.accepted.connect(self.save)
        btns.rejected.connect(self.reject)
        layout.addRow(btns)
    
    def save(self):
        data = {
            'doc_id': self.doc_id,
            'from_entity': self.from_edit.text(),
            'to_entity': self.to_edit.text(),
            'subject': self.subject_edit.text(),
            'content': self.content_edit.toPlainText(),
            'sent_date': self.sent_date.date().toString("yyyy-MM-dd"),
            'received_date': self.received_date.date().toString("yyyy-MM-dd"),
            'status': self.status_combo.currentText(),
            'tracking_number': self.tracking_edit.text()
        }
        service = CorrespondenceService(self.db_manager)
        service.add_correspondence(data)
        self.accept()
