# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt, QPropertyAnimation, QEasingCurve
from PyQt5.QtGui import QFont, QIcon, QPixmap, QLinearGradient, QPalette, QBrush, QColor
from PyQt5.QtWidgets import QGraphicsDropShadowEffect

class LoginWindow(QMainWindow):
    def __init__(self, controller):
        super().__init__()
        self.controller = controller
        self.setWindowTitle("نظام الأرشفة الإلكتروني - تسجيل الدخول")
        self.setFixedSize(500, 600)
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setStyleSheet("""
            QMainWindow {
                background: transparent;
            }
        """)
        
        self.setLayoutDirection(Qt.RightToLeft)
        
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # بطاقة بيضاء مع ظل
        card = QFrame()
        card.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 20px;
                border: none;
            }
        """)
        card_layout = QVBoxLayout(card)
        card_layout.setSpacing(25)
        card_layout.setContentsMargins(40, 50, 40, 50)
        
        # أيقونة البرنامج
        logo_label = QLabel("📁")
        logo_label.setAlignment(Qt.AlignCenter)
        logo_label.setStyleSheet("font-size: 70px;")
        card_layout.addWidget(logo_label)
        
        # العنوان
        title = QLabel("نظام الأرشفة الإلكتروني")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("""
            font-size: 24px;
            font-weight: bold;
            color: #1e3c72;
            margin-bottom: 20px;
        """)
        card_layout.addWidget(title)
        
        # حقول الإدخال
        self.username_edit = QLineEdit()
        self.username_edit.setPlaceholderText("اسم المستخدم")
        self.username_edit.setStyleSheet("""
            QLineEdit {
                padding: 12px;
                font-size: 14px;
                border: 1px solid #d1d5db;
                border-radius: 10px;
                background: #f9fafb;
            }
            QLineEdit:focus {
                border-color: #1e3c72;
                background: white;
            }
        """)
        card_layout.addWidget(self.username_edit)
        
        self.password_edit = QLineEdit()
        self.password_edit.setPlaceholderText("كلمة المرور")
        self.password_edit.setEchoMode(QLineEdit.Password)
        self.password_edit.setStyleSheet("""
            QLineEdit {
                padding: 12px;
                font-size: 14px;
                border: 1px solid #d1d5db;
                border-radius: 10px;
                background: #f9fafb;
            }
            QLineEdit:focus {
                border-color: #1e3c72;
                background: white;
            }
        """)
        card_layout.addWidget(self.password_edit)
        
        # إظهار كلمة المرور
        self.show_password_cb = QCheckBox("إظهار كلمة المرور")
        self.show_password_cb.setStyleSheet("color: #4b5563; margin-top: 5px;")
        self.show_password_cb.stateChanged.connect(self.toggle_password)
        card_layout.addWidget(self.show_password_cb)
        
        # زر تسجيل الدخول
        login_btn = QPushButton("تسجيل الدخول")
        login_btn.setCursor(Qt.PointingHandCursor)
        login_btn.setStyleSheet("""
            QPushButton {
                background-color: #1e3c72;
                color: white;
                border: none;
                padding: 12px;
                border-radius: 10px;
                font-size: 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2c5a92;
            }
        """)
        login_btn.clicked.connect(self.do_login)
        card_layout.addWidget(login_btn)
        
        # تذييل
        designer_label = QLabel("تصميم: ن/أكرم ياسين 777425435")
        designer_label.setAlignment(Qt.AlignCenter)
        designer_label.setStyleSheet("color: #9ca3af; font-size: 11px; margin-top: 20px;")
        card_layout.addWidget(designer_label)
        
        layout.addWidget(card)
        
        # تأثير الظل
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(20)
        shadow.setOffset(0, 5)
        shadow.setColor(QColor(0, 0, 0, 80))
        card.setGraphicsEffect(shadow)
        
        self.username_edit.setFocus()
    
    def toggle_password(self, state):
        if state == Qt.Checked:
            self.password_edit.setEchoMode(QLineEdit.Normal)
        else:
            self.password_edit.setEchoMode(QLineEdit.Password)
    
    def do_login(self):
        username = self.username_edit.text().strip()
        password = self.password_edit.text()
        if not username or not password:
            QMessageBox.warning(self, "تنبيه", "يرجى إدخال اسم المستخدم وكلمة المرور")
            return
        self.controller.login(username, password)