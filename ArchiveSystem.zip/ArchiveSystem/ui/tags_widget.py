
# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import *
from services.tag_service import TagService

class TagsWidget(QWidget):
    def __init__(self, db_manager):
        super().__init__()
        self.db_manager = db_manager
        self.service = TagService(db_manager)
        self.init_ui()
        self.load_tags()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        self.list_widget = QListWidget()
        layout.addWidget(self.list_widget)
        add_layout = QHBoxLayout()
        self.new_tag_edit = QLineEdit()
        self.new_tag_edit.setPlaceholderText("كلمة مفتاحية جديدة")
        add_btn = QPushButton("إضافة")
        add_btn.clicked.connect(self.add_tag)
        add_layout.addWidget(self.new_tag_edit)
        add_layout.addWidget(add_btn)
        layout.addLayout(add_layout)
    
    def load_tags(self):
        tags = self.service.get_all_tags()
        self.list_widget.clear()
        for tag in tags:
            self.list_widget.addItem(f"{tag['name']} (استخدم {tag['usage_count']} مرة)")
    
    def add_tag(self):
        name = self.new_tag_edit.text().strip()
        if name:
            self.service.add_tag(name)
            self.load_tags()
            self.new_tag_edit.clear()
