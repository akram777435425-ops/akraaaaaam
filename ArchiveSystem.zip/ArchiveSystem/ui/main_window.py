# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QFont, QKeySequence
from ui.dashboard_widget import DashboardWidget
from ui.user_management_widget import UserManagementWidget
from ui.document_management_widget import DocumentManagementWidget
from ui.search_widget import SearchWidget
from ui.reports_widget import ReportsWidget
from ui.settings_widget import SettingsWidget
from ui.archive_widget import ArchiveWidget
from ui.parties_widget import PartiesWidget
from ui.categories_widget import CategoriesWidget
from ui.backup_widget import BackupWidget
from ui.correspondence_widget import CorrespondenceWidget
from ui.tags_widget import TagsWidget
from ui.contacts_management_widget import ContactsManagementWidget
from ui.help_dialog import HelpDialog

class MainWindow(QMainWindow):
    def __init__(self, db_manager, log_manager, user):
        super().__init__()
        self.db_manager = db_manager
        self.log_manager = log_manager
        self.current_user = user
        self.setWindowTitle(f"نظام الأرشفة الإلكتروني - مرحباً {user['full_name']}")
        self.setGeometry(100, 100, 1400, 800)
        self.setStyleSheet(self.load_styles())
        self.setLayoutDirection(Qt.RightToLeft)
        
        # القائمة الجانبية
        self.sidebar = QListWidget()
        self.sidebar.setFixedWidth(280)
        self.sidebar.setIconSize(QSize(32, 32))
        self.sidebar.setStyleSheet("""
            QListWidget {
                background-color: #1e3c72;
                color: white;
                border: none;
                font-size: 15px;
                outline: none;
            }
            QListWidget::item {
                padding: 15px 20px;
                border-bottom: 1px solid #2c4a7a;
            }
            QListWidget::item:selected {
                background-color: #2c5a92;
                border-left: 4px solid #ffc107;
            }
            QListWidget::item:hover {
                background-color: #2c4a7a;
            }
        """)
        
        menu_items = [
            ("📊", "لوحة التحكم"),
            ("📄", "الوثائق"),
            ("🔍", "بحث متقدم"),
            ("👥", "المستخدمين"),
            ("📎", "الجهات الخارجية"),
            ("🏷️", "التصنيفات"),
            ("📞", "جهات الاتصال (مرسل/مستلم)"),
            ("🔄", "المراسلات"),
            ("🏷️", "الكلمات المفتاحية"),
            ("📦", "الأرشيف"),
            ("📑", "التقارير"),
            ("⚙️", "الإعدادات"),
            ("💾", "النسخ الاحتياطي"),
            ("🚪", "تسجيل الخروج")
        ]
        for icon, text in menu_items:
            item = QListWidgetItem(f"{icon}  {text}")
            item.setData(Qt.UserRole, text)
            self.sidebar.addItem(item)
        
        self.sidebar.currentItemChanged.connect(self.change_page)
        
        # منطقة المحتوى
        self.stacked = QStackedWidget()
        self.stacked.setStyleSheet("""
            QStackedWidget {
                background-color: #f8fafc;
                border-radius: 15px;
            }
        """)
        
        self.dashboard_widget = DashboardWidget(db_manager, user)
        self.doc_widget = DocumentManagementWidget(db_manager, user)
        self.search_widget = SearchWidget(db_manager)
        self.user_widget = UserManagementWidget(db_manager, user)
        self.parties_widget = PartiesWidget(db_manager)
        self.categories_widget = CategoriesWidget(db_manager)
        self.contacts_widget = ContactsManagementWidget(db_manager)
        self.correspondence_widget = CorrespondenceWidget(db_manager)
        self.tags_widget = TagsWidget(db_manager)
        self.archive_widget = ArchiveWidget(db_manager)
        self.reports_widget = ReportsWidget(db_manager)
        self.settings_widget = SettingsWidget(db_manager)
        self.backup_widget = BackupWidget(db_manager)
        
        self.stacked.addWidget(self.dashboard_widget)
        self.stacked.addWidget(self.doc_widget)
        self.stacked.addWidget(self.search_widget)
        self.stacked.addWidget(self.user_widget)
        self.stacked.addWidget(self.parties_widget)
        self.stacked.addWidget(self.categories_widget)
        self.stacked.addWidget(self.contacts_widget)
        self.stacked.addWidget(self.correspondence_widget)
        self.stacked.addWidget(self.tags_widget)
        self.stacked.addWidget(self.archive_widget)
        self.stacked.addWidget(self.reports_widget)
        self.stacked.addWidget(self.settings_widget)
        self.stacked.addWidget(self.backup_widget)
        
        main_layout = QHBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        main_layout.addWidget(self.sidebar)
        main_layout.addWidget(self.stacked, 1)
        
        container = QWidget()
        container.setLayout(main_layout)
        self.setCentralWidget(container)
        
        # شريط الحالة مع زر المساعدة
        self.statusBar().setStyleSheet("""
            QStatusBar {
                background-color: #e2e8f0;
                color: #1e3c72;
                padding: 5px;
            }
        """)
        self.statusBar().showMessage("تم تحميل النظام بنجاح")
        
        # زر مساعدة في شريط الحالة (أقصى اليمين)
        help_btn = QPushButton("❓ مساعدة")
        help_btn.setCursor(Qt.PointingHandCursor)
        help_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #1e3c72;
                border: none;
                font-weight: bold;
                padding: 2px 8px;
            }
            QPushButton:hover {
                color: #ffc107;
            }
        """)
        help_btn.clicked.connect(lambda: HelpDialog("general", self).exec_())
        self.statusBar().addPermanentWidget(help_btn)
        
        # صلاحيات المستخدمين
        if user['role'] != 'admin':
            self.sidebar.item(3).setFlags(Qt.NoItemFlags)  # إخفاء المستخدمين
        
        # اختصارات لوحة المفاتيح
        self.shortcut_add = QShortcut(QKeySequence("Ctrl+N"), self)
        self.shortcut_add.activated.connect(self.doc_widget.add_document)
        self.shortcut_refresh = QShortcut(QKeySequence("F5"), self)
        self.shortcut_refresh.activated.connect(self.doc_widget.refresh_table)
        self.shortcut_search = QShortcut(QKeySequence("Ctrl+F"), self)
        self.shortcut_search.activated.connect(lambda: self.sidebar.setCurrentRow(2))
    
    def load_styles(self):
        return """
            QMainWindow {
                background-color: #f1f5f9;
            }
            QTableWidget {
                alternate-background-color: #ffffff;
                selection-background-color: #e2e8f0;
                gridline-color: #cbd5e1;
                font-size: 13px;
                border-radius: 10px;
            }
            QPushButton {
                background-color: #1e3c72;
                color: white;
                border-radius: 8px;
                padding: 8px 18px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2c5a92;
            }
            QLineEdit, QComboBox, QDateEdit, QTextEdit {
                padding: 8px;
                border: 1px solid #cbd5e1;
                border-radius: 8px;
                background: white;
            }
            QLineEdit:focus, QComboBox:focus, QDateEdit:focus, QTextEdit:focus {
                border-color: #1e3c72;
            }
        """
    
    def change_page(self, current, previous):
        if not current:
            return
        page_name = current.data(Qt.UserRole)
        if page_name == "تسجيل الخروج":
            self.close()
            from controllers.auth_controller import AuthController
            self.auth_controller = AuthController(self.db_manager, self.log_manager)
            self.auth_controller.show_login()
        else:
            index = self.sidebar.row(current)
            if index < self.stacked.count():
                self.stacked.setCurrentIndex(index)
    
    def closeEvent(self, event):
        reply = QMessageBox.question(self, 'تأكيد الخروج',
                                     'هل تريد الخروج من البرنامج؟',
                                     QMessageBox.Yes | QMessageBox.No,
                                     QMessageBox.No)
        if reply == QMessageBox.Yes:
            event.accept()
        else:
            event.ignore()