# -*- coding: utf-8 -*-
import os
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt, QDate
from controllers.document_controller import DocumentController
from services.scan_service import ScanService
from services.contact_service import ContactService
from database.db_manager import DatabaseManager
from ui.view_document_dialog import ViewDocumentDialog
from ui.help_dialog import HelpDialog

class DocumentManagementWidget(QWidget):
    def __init__(self, db_manager: DatabaseManager, user: dict):
        super().__init__()
        self.db_manager = db_manager
        self.current_user = user
        self.controller = DocumentController(db_manager)
        self.scan_service = ScanService()
        self.contact_service = ContactService(db_manager)
        self.init_ui()
        self.refresh_table()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # شريط العنوان مع زر المساعدة
        top_layout = QHBoxLayout()
        title = QLabel("📄 الوثائق")
        title.setStyleSheet("font-size: 22px; font-weight: bold; color: #1e3c72;")
        help_btn = QPushButton("❓")
        help_btn.setFixedSize(30, 30)
        help_btn.setToolTip("مساعدة حول إدارة الوثائق")
        help_btn.setCursor(Qt.PointingHandCursor)
        help_btn.clicked.connect(lambda: HelpDialog("documents", self).exec_())
        top_layout.addWidget(title)
        top_layout.addWidget(help_btn)
        top_layout.addStretch()
        layout.addLayout(top_layout)
        
        toolbar = QHBoxLayout()
        self.add_btn = QPushButton("➕ إضافة وثيقة")
        self.edit_btn = QPushButton("✏️ تعديل")
        self.delete_btn = QPushButton("📦 أرشفة")
        self.hard_delete_btn = QPushButton("🗑️ حذف نهائي")
        self.restore_btn = QPushButton("🔄 استرجاع")
        self.scan_btn = QPushButton("📷 مسح ضوئي")
        self.refresh_btn = QPushButton("🔄 تحديث")
        
        # إضافة Tooltips للأزرار
        self.add_btn.setToolTip("إضافة وثيقة جديدة (Ctrl+N)")
        self.edit_btn.setToolTip("تعديل الوثيقة المحددة")
        self.delete_btn.setToolTip("نقل الوثيقة إلى الأرشيف (يمكن استرجاعها لاحقاً)")
        self.hard_delete_btn.setToolTip("حذف الوثيقة وجميع مرفقاتها بشكل دائم - لا يمكن التراجع")
        self.restore_btn.setToolTip("استرجاع وثيقة من الأرشيف إلى الوثائق النشطة")
        self.scan_btn.setToolTip("تشغيل الماسح الضوئي وإضافة الصورة كمرفق")
        self.refresh_btn.setToolTip("تحديث جدول الوثائق (F5)")
        
        self.add_btn.clicked.connect(self.add_document)
        self.edit_btn.clicked.connect(self.edit_document)
        self.delete_btn.clicked.connect(self.archive_document)
        self.hard_delete_btn.clicked.connect(self.hard_delete_document)
        self.restore_btn.clicked.connect(self.restore_document)
        self.scan_btn.clicked.connect(self.scan_document)
        self.refresh_btn.clicked.connect(self.refresh_table)
        
        for btn in [self.add_btn, self.edit_btn, self.delete_btn, self.hard_delete_btn, self.restore_btn, self.scan_btn, self.refresh_btn]:
            btn.setMinimumHeight(35)
            toolbar.addWidget(btn)
        layout.addLayout(toolbar)
        
        self.table = QTableWidget()
        self.table.setColumnCount(13)
        self.table.setHorizontalHeaderLabels([
            "ID", "رقم المعاملة", "رقم الوثيقة", "العنوان", "التاريخ", "المرسل", "المستلم",
            "النوع", "الحالة", "أولوية", "جهة خارجية", "مرفقات", "مؤرشف"
        ])
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.doubleClicked.connect(self.view_document)
        layout.addWidget(self.table)
    
    def refresh_table(self):
        docs = self.controller.get_all_documents(archived=False)
        self.table.setRowCount(len(docs))
        for i, doc in enumerate(docs):
            self.table.setItem(i, 0, QTableWidgetItem(str(doc['id'])))
            self.table.setItem(i, 1, QTableWidgetItem(str(doc.get('transaction_number', ''))))
            self.table.setItem(i, 2, QTableWidgetItem(doc['doc_number']))
            self.table.setItem(i, 3, QTableWidgetItem(doc['title']))
            self.table.setItem(i, 4, QTableWidgetItem(doc.get('doc_date', '')))
            self.table.setItem(i, 5, QTableWidgetItem(doc.get('sender_name', '')))
            self.table.setItem(i, 6, QTableWidgetItem(doc.get('recipient_name', '')))
            self.table.setItem(i, 7, QTableWidgetItem(doc.get('doc_type', '')))
            self.table.setItem(i, 8, QTableWidgetItem(doc.get('doc_status', '')))
            self.table.setItem(i, 9, QTableWidgetItem(doc.get('priority', '')))
            self.table.setItem(i, 10, QTableWidgetItem(doc.get('correspondent_name', '')))
            att_count = len(self.controller.doc_service.get_attachments(doc['id']))
            self.table.setItem(i, 11, QTableWidgetItem(str(att_count)))
            self.table.setItem(i, 12, QTableWidgetItem('نعم' if doc.get('is_archived') else 'لا'))
    
    def add_document(self):
        dialog = DocumentDialog(self.db_manager, self.current_user, self.controller)
        if dialog.exec_():
            self.refresh_table()
    
    def edit_document(self):
        selected = self.table.currentRow()
        if selected < 0:
            QMessageBox.warning(self, "تنبيه", "يرجى اختيار وثيقة للتعديل")
            return
        doc_id = int(self.table.item(selected, 0).text())
        dialog = DocumentDialog(self.db_manager, self.current_user, self.controller, doc_id)
        if dialog.exec_():
            self.refresh_table()
    
    def archive_document(self):
        selected = self.table.currentRow()
        if selected < 0:
            return
        doc_id = int(self.table.item(selected, 0).text())
        confirm = QMessageBox.question(self, "تأكيد", "هل تريد أرشفة هذه الوثيقة؟", QMessageBox.Yes|QMessageBox.No)
        if confirm == QMessageBox.Yes:
            self.controller.delete_document(doc_id, hard=False)
            self.refresh_table()
    
    def hard_delete_document(self):
        selected = self.table.currentRow()
        if selected < 0:
            return
        doc_id = int(self.table.item(selected, 0).text())
        confirm = QMessageBox.question(self, "تأكيد", "سيتم حذف الوثيقة وجميع مرفقاتها نهائياً. استمرار؟", QMessageBox.Yes|QMessageBox.No)
        if confirm == QMessageBox.Yes:
            self.controller.delete_document(doc_id, hard=True)
            self.refresh_table()
    
    def restore_document(self):
        selected = self.table.currentRow()
        if selected < 0:
            return
        doc_id = int(self.table.item(selected, 0).text())
        self.controller.restore_document(doc_id)
        self.refresh_table()
    
    def scan_document(self):
        scanned_path = self.scan_service.scan_document(self)
        if scanned_path:
            dialog = DocumentDialog(self.db_manager, self.current_user, self.controller, scanned_file=scanned_path)
            if dialog.exec_():
                self.refresh_table()
    
    def view_document(self, index):
        doc_id = int(self.table.item(index.row(), 0).text())
        dlg = ViewDocumentDialog(self.db_manager, doc_id, self.current_user)
        dlg.exec_()


class DocumentDialog(QDialog):
    def __init__(self, db_manager, user, controller, doc_id=None, scanned_file=None):
        super().__init__()
        self.db_manager = db_manager
        self.user = user
        self.controller = controller
        self.doc_id = doc_id
        self.scanned_file = scanned_file
        self.temp_attachments = []
        self.contact_service = ContactService(db_manager)
        self.setWindowTitle("إضافة / تعديل وثيقة")
        self.setMinimumWidth(1000)
        self.setMinimumHeight(750)
        self.setStyleSheet("""
            QDialog { background-color: #f8fafc; }
            QGroupBox {
                font-weight: bold;
                border: 1px solid #cbd5e1;
                border-radius: 12px;
                margin-top: 12px;
                padding-top: 10px;
                background-color: white;
            }
            QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 8px; color: #1e3c72; }
            QLabel { font-size: 13px; font-weight: 500; color: #2c3e50; }
            QLineEdit, QComboBox, QDateEdit, QTextEdit {
                padding: 8px 12px;
                min-height: 36px;
                border-radius: 8px;
                border: 1px solid #cbd5e1;
                background: white;
                font-size: 13px;
            }
            QLineEdit:focus, QComboBox:focus, QDateEdit:focus, QTextEdit:focus {
                border-color: #1e3c72;
            }
            QTextEdit { min-height: 80px; }
            QPushButton {
                background-color: #1e3c72;
                color: white;
                border-radius: 8px;
                padding: 8px 16px;
                min-height: 35px;
                font-weight: bold;
            }
            QPushButton:hover { background-color: #2c5a92; }
            QTabWidget::pane {
                border-radius: 12px;
                border: 1px solid #cbd5e1;
                background-color: white;
            }
            QTabBar::tab {
                background: #e9ecef;
                border-radius: 8px 8px 0 0;
                padding: 8px 16px;
                margin-right: 4px;
                font-weight: bold;
            }
            QTabBar::tab:selected {
                background: white;
                border-bottom: 2px solid #1e3c72;
            }
        """)
        self.setLayoutDirection(Qt.RightToLeft)
        self.init_ui()
        if doc_id:
            self.load_document_data()
    
    def init_ui(self):
        main_layout = QVBoxLayout(self)
        
        # زر مساعدة داخل النافذة
        help_btn = QPushButton("❓")
        help_btn.setFixedSize(30, 30)
        help_btn.setToolTip("مساعدة حول إضافة/تعديل وثيقة")
        help_btn.setCursor(Qt.PointingHandCursor)
        help_btn.clicked.connect(lambda: HelpDialog("documents", self).exec_())
        main_layout.addWidget(help_btn, alignment=Qt.AlignLeft)
        
        tabs = QTabWidget()
        
        # ----- تبويب المعلومات الأساسية -----
        basic_tab = QWidget()
        basic_layout = QVBoxLayout(basic_tab)
        basic_layout.setSpacing(20)
        
        main_group = QGroupBox("المعلومات الأساسية")
        main_grid = QGridLayout(main_group)
        main_grid.setVerticalSpacing(15)
        main_grid.setHorizontalSpacing(20)
        
        self.transaction_number_edit = QLineEdit()
        self.transaction_number_edit.setToolTip("رقم فريد للمعاملة، لا يمكن تكراره لنفس السنة ونفس النوع (وارد/صادر)")
        main_grid.addWidget(QLabel("رقم المعاملة *:"), 0, 0)
        main_grid.addWidget(self.transaction_number_edit, 0, 1)
        
        self.title_edit = QLineEdit()
        self.title_edit.setToolTip("عنوان الوثيقة (إجباري)")
        main_grid.addWidget(QLabel("العنوان *:"), 0, 2)
        main_grid.addWidget(self.title_edit, 0, 3)
        
        self.doc_number_edit = QLineEdit()
        self.doc_number_edit.setReadOnly(True)
        self.doc_number_edit.setToolTip("رقم تلقائي ينشأ عند الحفظ")
        main_grid.addWidget(QLabel("رقم الوثيقة (تلقائي):"), 1, 0)
        main_grid.addWidget(self.doc_number_edit, 1, 1)
        
        self.doc_date_edit = QDateEdit()
        self.doc_date_edit.setCalendarPopup(True)
        self.doc_date_edit.setDate(QDate.currentDate())
        self.doc_date_edit.setToolTip("تاريخ الوثيقة - يُستخدم لتحديد السنة في مسار الأرشيف")
        cal = self.doc_date_edit.calendarWidget()
        cal.setLayoutDirection(Qt.RightToLeft)
        main_grid.addWidget(QLabel("التاريخ:"), 1, 2)
        main_grid.addWidget(self.doc_date_edit, 1, 3)
        
        self.sender_combo = QComboBox()
        self.sender_combo.setToolTip("اختر المرسل من قائمة جهات الاتصال الداخلية")
        main_grid.addWidget(QLabel("المرسل (من القائمة):"), 2, 0)
        main_grid.addWidget(self.sender_combo, 2, 1)
        
        self.recipient_combo = QComboBox()
        self.recipient_combo.setToolTip("اختر المستلم من قائمة جهات الاتصال الداخلية")
        main_grid.addWidget(QLabel("المستلم (من القائمة):"), 2, 2)
        main_grid.addWidget(self.recipient_combo, 2, 3)
        
        self.description_edit = QTextEdit()
        self.description_edit.setToolTip("وصف تفصيلي لمحتوى الوثيقة")
        main_grid.addWidget(QLabel("الوصف:"), 3, 0, Qt.AlignTop)
        main_grid.addWidget(self.description_edit, 3, 1, 1, 3)
        basic_layout.addWidget(main_group)
        
        second_group = QGroupBox("التصنيف والجهات")
        second_grid = QGridLayout(second_group)
        second_grid.setVerticalSpacing(15)
        second_grid.setHorizontalSpacing(20)
        
        self.type_combo = QComboBox()
        self.type_combo.addItems(["عادي", "سري", "هام"])
        self.type_combo.setToolTip("نوع الوثيقة: عادي، سري، هام")
        second_grid.addWidget(QLabel("النوع:"), 0, 0)
        second_grid.addWidget(self.type_combo, 0, 1)
        
        self.status_combo = QComboBox()
        self.status_combo.addItems(["جديدة", "قيد التنفيذ", "مكتملة", "مرفوضة"])
        self.status_combo.setToolTip("حالة المعاملة")
        second_grid.addWidget(QLabel("الحالة:"), 0, 2)
        second_grid.addWidget(self.status_combo, 0, 3)
        
        self.priority_combo = QComboBox()
        self.priority_combo.addItems(["عادية", "متوسطة", "عالية", "عاجلة"])
        self.priority_combo.setToolTip("أولوية المعاملة")
        second_grid.addWidget(QLabel("الأولوية:"), 1, 0)
        second_grid.addWidget(self.priority_combo, 1, 1)
        
        self.category_combo = QComboBox()
        self.category_combo.setToolTip("اختر تصنيفاً من الشجرة")
        second_grid.addWidget(QLabel("التصنيف:"), 1, 2)
        second_grid.addWidget(self.category_combo, 1, 3)
        
        self.correspondent_combo = QComboBox()
        self.correspondent_combo.setToolTip("الجهة الخارجية المرتبطة بالوثيقة (شركة، وزارة، إلخ)")
        second_grid.addWidget(QLabel("الجهة الخارجية:"), 2, 0)
        second_grid.addWidget(self.correspondent_combo, 2, 1)
        
        self.in_out_combo = QComboBox()
        self.in_out_combo.addItems(["وارد", "صادر"])
        self.in_out_combo.setToolTip("وارد: دخل إلى مؤسستك، صادر: خرج من مؤسستك")
        second_grid.addWidget(QLabel("وارد/صادر:"), 2, 2)
        second_grid.addWidget(self.in_out_combo, 2, 3)
        
        self.tags_edit = QLineEdit()
        self.tags_edit.setPlaceholderText("مثال: عقود, مالية, 2025")
        self.tags_edit.setToolTip("كلمات مفتاحية مفصولة بفواصل، مثال: عقود, مالية, 2025")
        second_grid.addWidget(QLabel("الكلمات المفتاحية:"), 3, 0)
        second_grid.addWidget(self.tags_edit, 3, 1, 1, 3)
        basic_layout.addWidget(second_group)
        
        third_group = QGroupBox("معلومات إضافية")
        third_grid = QGridLayout(third_group)
        third_grid.setVerticalSpacing(15)
        third_grid.setHorizontalSpacing(20)
        
        self.confidentiality_combo = QComboBox()
        self.confidentiality_combo.addItems(["عادي", "داخلي", "سري", "شديد السرية"])
        self.confidentiality_combo.setToolTip("مستوى السرية")
        third_grid.addWidget(QLabel("مستوى السرية:"), 0, 0)
        third_grid.addWidget(self.confidentiality_combo, 0, 1)
        
        self.review_date_edit = QDateEdit()
        self.review_date_edit.setCalendarPopup(True)
        self.review_date_edit.setDate(QDate.currentDate().addYears(1))
        self.review_date_edit.setToolTip("تاريخ مراجعة الوثيقة (للتذكير)")
        third_grid.addWidget(QLabel("تاريخ المراجعة:"), 0, 2)
        third_grid.addWidget(self.review_date_edit, 0, 3)
        
        self.location_code_edit = QLineEdit()
        self.location_code_edit.setPlaceholderText("خزانة-رف-مجلد")
        self.location_code_edit.setToolTip("رمز الموقع الفعلي للوثيقة (إن وجد)")
        third_grid.addWidget(QLabel("رمز الموقع:"), 1, 0)
        third_grid.addWidget(self.location_code_edit, 1, 1, 1, 3)
        basic_layout.addWidget(third_group)
        basic_layout.addStretch()
        tabs.addTab(basic_tab, "📋 معلومات أساسية")
        
        # ----- تبويب المرفقات -----
        attach_tab = QWidget()
        attach_layout = QVBoxLayout(attach_tab)
        attach_layout.setSpacing(15)
        attach_group = QGroupBox("إدارة المرفقات")
        attach_group_layout = QVBoxLayout(attach_group)
        self.attachments_list = QListWidget()
        self.attachments_list.setMinimumHeight(200)
        self.attachments_list.setToolTip("قائمة الملفات المرفقة. انقر نقراً مزدوجاً لمعاينة الملف")
        self.attachments_list.setAcceptDrops(True)
        attach_group_layout.addWidget(self.attachments_list)
        btn_layout = QHBoxLayout()
        add_btn = QPushButton("➕ إضافة ملف")
        remove_btn = QPushButton("🗑️ إزالة")
        add_btn.setToolTip("إضافة ملف جديد (PDF، صورة، Word، إلخ)")
        remove_btn.setToolTip("إزالة الملف المحدد من القائمة")
        add_btn.clicked.connect(self.add_attachment)
        remove_btn.clicked.connect(self.remove_attachment)
        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(remove_btn)
        attach_group_layout.addLayout(btn_layout)
        attach_layout.addWidget(attach_group)
        attach_layout.addStretch()
        tabs.addTab(attach_tab, "📎 المرفقات")
        
        main_layout.addWidget(tabs)
        
        btn_row = QHBoxLayout()
        save_btn = QPushButton("💾 حفظ")
        save_new_btn = QPushButton("➕ حفظ وإضافة أخرى")
        cancel_btn = QPushButton("✖️ إلغاء")
        save_btn.setToolTip("حفظ الوثيقة وإغلاق النافذة")
        save_new_btn.setToolTip("حفظ الوثيقة والبقاء لإضافة أخرى")
        cancel_btn.setToolTip("إلغاء العملية")
        save_btn.clicked.connect(self.save_and_close)
        save_new_btn.clicked.connect(self.save_and_new)
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(save_btn)
        btn_row.addWidget(save_new_btn)
        btn_row.addWidget(cancel_btn)
        main_layout.addLayout(btn_row)
        
        self.load_contacts_combos()
        self.load_categories()
        self.load_correspondents()
        
        if self.scanned_file:
            self.temp_attachments.append(self.scanned_file)
            self.attachments_list.addItem(os.path.basename(self.scanned_file))
    
    def load_contacts_combos(self):
        try:
            senders = self.contact_service.get_contacts_by_type('sender')
            recipients = self.contact_service.get_contacts_by_type('recipient')
            self.sender_combo.clear()
            self.recipient_combo.clear()
            self.sender_combo.addItem("(بدون)", None)
            self.recipient_combo.addItem("(بدون)", None)
            for s in senders:
                self.sender_combo.addItem(s['name'], s['id'])
            for r in recipients:
                self.recipient_combo.addItem(r['name'], r['id'])
        except Exception as e:
            print(f"Error loading contacts: {e}")
    
    def load_categories(self):
        try:
            with self.db_manager.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT id, name FROM categories")
                self.category_combo.clear()
                self.category_combo.addItem("(بدون)", None)
                for row in cursor.fetchall():
                    self.category_combo.addItem(row['name'], row['id'])
        except Exception as e:
            print(f"Error loading categories: {e}")
    
    def load_correspondents(self):
        try:
            with self.db_manager.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT id, name, code FROM correspondents")
                self.correspondent_combo.clear()
                self.correspondent_combo.addItem("(بدون)", None)
                for row in cursor.fetchall():
                    self.correspondent_combo.addItem(f"{row['name']} ({row['code']})", row['id'])
        except Exception as e:
            print(f"Error loading correspondents: {e}")
    
    def load_document_data(self):
        doc = self.controller.doc_service.get_document(self.doc_id)
        if doc:
            self.transaction_number_edit.setText(doc.get('transaction_number', ''))
            self.title_edit.setText(doc['title'])
            self.doc_number_edit.setText(doc['doc_number'])
            if doc['doc_date']:
                self.doc_date_edit.setDate(QDate.fromString(doc['doc_date'], "yyyy-MM-dd"))
            sender_id = doc.get('sender_id')
            recipient_id = doc.get('recipient_id')
            if sender_id:
                idx = self.sender_combo.findData(sender_id)
                if idx >= 0:
                    self.sender_combo.setCurrentIndex(idx)
            if recipient_id:
                idx = self.recipient_combo.findData(recipient_id)
                if idx >= 0:
                    self.recipient_combo.setCurrentIndex(idx)
            self.description_edit.setPlainText(doc.get('description', ''))
            self.type_combo.setCurrentText(doc.get('doc_type', 'عادي'))
            self.status_combo.setCurrentText(doc.get('doc_status', 'جديدة'))
            self.priority_combo.setCurrentText(doc.get('priority', 'عادية'))
            if doc.get('category_id'):
                idx = self.category_combo.findData(doc['category_id'])
                if idx >= 0:
                    self.category_combo.setCurrentIndex(idx)
            if doc.get('correspondent_id'):
                idx = self.correspondent_combo.findData(doc['correspondent_id'])
                if idx >= 0:
                    self.correspondent_combo.setCurrentIndex(idx)
            self.in_out_combo.setCurrentText(doc.get('incoming_outgoing', 'وارد'))
            self.tags_edit.setText(doc.get('tags', ''))
            self.confidentiality_combo.setCurrentText(doc.get('confidentiality', 'عادي'))
            if doc.get('review_date'):
                self.review_date_edit.setDate(QDate.fromString(doc['review_date'], "yyyy-MM-dd"))
            self.location_code_edit.setText(doc.get('location_code', ''))
            attachments = self.controller.doc_service.get_attachments(self.doc_id)
            for att in attachments:
                self.attachments_list.addItem(att['filename'])
    
    def add_attachment(self):
        files, _ = QFileDialog.getOpenFileNames(self, "اختر الملفات", "", "جميع الملفات (*.*)")
        for f in files:
            self.temp_attachments.append(f)
            self.attachments_list.addItem(os.path.basename(f))
    
    def remove_attachment(self):
        current = self.attachments_list.currentRow()
        if current >= 0:
            file_item = self.attachments_list.item(current).text()
            for idx, path in enumerate(self.temp_attachments):
                if os.path.basename(path) == file_item:
                    del self.temp_attachments[idx]
                    break
            self.attachments_list.takeItem(current)
    
    def save_and_new(self):
        if self.save():
            self.transaction_number_edit.clear()
            self.title_edit.clear()
            self.description_edit.clear()
            self.sender_combo.setCurrentIndex(0)
            self.recipient_combo.setCurrentIndex(0)
            self.tags_edit.clear()
            self.attachments_list.clear()
            self.temp_attachments.clear()
            self.doc_number_edit.clear()
            self.location_code_edit.clear()
            self.doc_date_edit.setDate(QDate.currentDate())
    
    def save_and_close(self):
        if self.save():
            self.accept()
    
    def save(self):
        transaction_number = self.transaction_number_edit.text().strip()
        if not transaction_number:
            QMessageBox.warning(self, "تنبيه", "رقم المعاملة مطلوب")
            return False
        
        title = self.title_edit.text().strip()
        if not title:
            QMessageBox.warning(self, "تنبيه", "العنوان مطلوب")
            return False
        
        doc_date = self.doc_date_edit.date()
        year = doc_date.year()
        
        data = {
            'transaction_number': transaction_number,
            'title': title,
            'doc_date': doc_date.toString("yyyy-MM-dd"),
            'sender_id': self.sender_combo.currentData(),
            'recipient_id': self.recipient_combo.currentData(),
            'description': self.description_edit.toPlainText(),
            'doc_type': self.type_combo.currentText(),
            'doc_status': self.status_combo.currentText(),
            'priority': self.priority_combo.currentText(),
            'category_id': self.category_combo.currentData(),
            'correspondent_id': self.correspondent_combo.currentData(),
            'incoming_outgoing': self.in_out_combo.currentText(),
            'tags': self.tags_edit.text(),
            'added_by': self.user['id'],
            'confidentiality': self.confidentiality_combo.currentText(),
            'review_date': self.review_date_edit.date().toString("yyyy-MM-dd"),
            'location_code': self.location_code_edit.text(),
            'year': year
        }
        
        try:
            if self.temp_attachments:
                progress = QProgressDialog("جاري رفع الملفات...", "إلغاء", 0, len(self.temp_attachments), self)
                progress.setWindowModality(Qt.WindowModal)
                progress.setMinimumDuration(0)
                progress.setValue(0)
            else:
                progress = None
            
            if self.doc_id:
                data['modified_by'] = self.user['id']
                success = self.controller.update_document(self.doc_id, data, self.temp_attachments)
            else:
                new_id = self.controller.add_document(data, self.temp_attachments)
                success = new_id is not None
                if success and data['tags']:
                    from services.tag_service import TagService
                    ts = TagService(self.db_manager)
                    for tag in data['tags'].split(','):
                        tag = tag.strip()
                        if tag:
                            ts.assign_tag_to_document(new_id, tag)
            
            if progress:
                progress.setValue(len(self.temp_attachments))
                progress.close()
            
            if success:
                QMessageBox.information(self, "تم", "تم حفظ الوثيقة بنجاح")
                return True
            else:
                QMessageBox.critical(self, "خطأ", "فشل حفظ الوثيقة")
                return False
        except ValueError as ve:
            QMessageBox.critical(self, "خطأ", str(ve))
            return False
        except Exception as e:
            QMessageBox.critical(self, "خطأ", f"حدث خطأ: {e}")
            return False