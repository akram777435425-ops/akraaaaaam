# -*- coding: utf-8 -*-
import sys
import os
from pathlib import Path

def get_data_dir():
    """إرجاع مجلد البيانات الرئيسي (في Documents)"""
    if os.name == 'nt':
        try:
            import ctypes.wintypes
            CSIDL_PERSONAL = 5
            buf = ctypes.create_unicode_buffer(ctypes.wintypes.MAX_PATH)
            ctypes.windll.shell32.SHGetFolderPathW(None, CSIDL_PERSONAL, None, 0, buf)
            docs = Path(buf.value)
        except:
            docs = Path.home() / "Documents"
    else:
        docs = Path.home() / "Documents"
    data_dir = docs / "ArchiveSystem"
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir

class Settings:
    APP_NAME = "ArchiveSystem"
    APP_VERSION = "1.0.0"
    DESIGNER = "ن/أكرم ياسين 777425435"
    
    # وضع التصحيح (True أثناء التطوير، False في الإنتاج)
    DEBUG = True  # غيّر إلى False عند بناء الإصدار النهائي
    
    DATA_DIR = get_data_dir()
    DB_PATH = DATA_DIR / "archive.db"
    BACKUP_DIR = DATA_DIR / "backup"
    LOGS_DIR = DATA_DIR / "logs"
    REPORTS_DIR = DATA_DIR / "reports"
    UPLOADS_DIR = DATA_DIR / "uploads"
    TEMP_DIR = DATA_DIR / "temp"
    
    DEFAULT_ARCHIVE_ROOT = DATA_DIR / "الأرشيف"
    ARCHIVE_ROOT = DEFAULT_ARCHIVE_ROOT   # سيتم تحديثه ديناميكياً عند تغيير الإعدادات
    
    DEFAULT_THEME = "light"
    AUTO_BACKUP_INTERVAL = 24
    DEFAULT_LANGUAGE = "ar"
    RTL_ENABLED = True
    
    @classmethod
    def ensure_directories(cls):
        for d in [cls.BACKUP_DIR, cls.LOGS_DIR, cls.REPORTS_DIR, cls.UPLOADS_DIR, cls.TEMP_DIR, cls.DEFAULT_ARCHIVE_ROOT]:
            d.mkdir(parents=True, exist_ok=True)

# إنشاء المجلدات الضرورية
Settings.ensure_directories()